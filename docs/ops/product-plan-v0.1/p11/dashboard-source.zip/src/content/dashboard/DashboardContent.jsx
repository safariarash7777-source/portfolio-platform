import React from "react";
import { DataComponent, DataTable, Filters, Section, SortableItem, SortableRegion, useDashboardTabs, useSectionFilters } from "../../data-app-public.jsx";
import "./dashboard.css";
const tabs = [{id:"incidents",label:"صف خطا",filterIds:[]},{id:"acceptance",label:"پذیرش قابلیت‌ها",filterIds:[]},{id:"support",label:"پیگیری پشتیبانی مصنوعی",filterIds:[]}];
const configs = {
 incidents: {query:"incident_queue",id:"incident-queue",title:"خطا، مسئول و اقدام بعدی",key:"id",fields:[["title","موضوع و نوع شاهد"],["owner","مسئول"],["priority","اولویت"],["status","وضعیت شاهد"],["next","اقدام بعدی"]]},
 acceptance: {query:"package_acceptance",id:"package-acceptance",title:"پذیرش P00 تا P11",key:"packageId",fields:[["packageId","بسته"],["capability","قابلیت"],["evidenceState","شاهد موجود"],["gates","گیت باز"],["owner","مسئول"],["human","پذیرش انسانی"]]},
 support: {query:"support_tracking",id:"support-tracking",title:"دریافت و لغو دسترسی؛ اجرای مصنوعی",key:"id",fields:[["state","وضعیت"],["result","نتیجه"],["eventAction","رخداد"],["kind","نوع شاهد"],["firstResponse","اولین پاسخ انسانی"],["sla","SLA"],["owner","مسئول"],["next","اقدام بعدی"]]}
};
function Queue({tab}) {
 const config=configs[tab];
 const scope=useSectionFilters([{id:"owner",label:"مسئول",field:"owner",defaultValue:"all",queryIds:[config.query]}],{}, {id:config.id+"-scope"});
 const scoped=scope.componentProps(config.query);
 return <Section id={config.id+"-heading"} title={config.title} filters={<Filters {...scope.filterProps}/> }>
  <SortableRegion id={config.id+"-canvas"} variant="canvas" spacing="standard" columns={12} rows={[{id:config.id+"-row",items:[config.id]}]} label="جدول شواهد">
   <SortableItem id={config.id} label={config.title} kind="table" span={12}>
    <DataComponent id={config.id} queryId={config.query} kind="table" title={config.title} variant="card" {...scoped}>
     <DataTable rows={scoped.displayRows} columns={config.fields.map(([field,label])=>({field,label,renderCell:field==="title"?(value,row)=><div>{value}<small className="p11-context">{row.kind} · {row.environment}</small></div>:field==="human"?()=>"OPEN":undefined}))} rowKey={config.key} label={config.title} searchable={tab!=="support"}/>
    </DataComponent>
   </SortableItem>
  </SortableRegion>
 </Section>;
}
export function DashboardContent(){
 const {activeTabId}=useDashboardTabs(tabs);
 const tab=configs[activeTabId]?activeTabId:"incidents";
 return <article className="p11-evidence" dir="rtl">
  <p className="p11-note" data-editable-id="p11-snapshot-note">نمونهٔ محلی از شواهد مستند ۲ اکتبر ۲۰۲۶. وضعیت جاری سرویس‌ها پایش نشده؛ دریافت پشتیبانی مصنوعی است و پذیرش انسانی همهٔ بسته‌ها باز است.</p>
  <Queue key={tab} tab={tab}/>
 </article>;
}
