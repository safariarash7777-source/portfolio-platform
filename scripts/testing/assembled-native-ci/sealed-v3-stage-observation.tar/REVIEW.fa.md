# driver محدودِ تجمیع‌شده، نسخهٔ قابل بررسی v2

وضعیت `SOURCE_READY_NATIVE_NOT_RUN` است. این بسته جایگزین capsule اجرایی v1 می‌شود؛ v1 و source آن محفوظ‌اند و نباید اجرا شوند. manifest برش اول با hash `82cfffe4...` و ۴۲ آزمون آن تغییر نکرده است.

مالک کد B است؛ هماهنگ‌کنندهٔ موجود مالک تخصیص و اجرای محیط Linux CI جداست. مخاطب این رسید، همان هماهنگ‌کننده و بازبین فنی است. مسئله، اتصال واقعی profile به runtime/gateway و driver موجود، با منبع دقیقِ نسخهٔ تجمیع‌شده است. خروجی، هشت helper تازهٔ `assembled-*`، materializer، diff، آزمون اتصال و capsule است. معیار پایان آماده‌سازی، صحت منبع/اتصال و آزمون آفلاین است؛ معیار اجرای آینده، ۱۴ بررسی محدود و پاکسازی واقعی است.

اصلاح v2: بازبینی نشان داد signOut واقعی SDK به `POST /auth/v1/logout?scope=global` نیاز دارد؛ observer v1 این درخواست را هم مسدود می‌کرد. policy به module مستقل منتقل شد؛ فقط همین POST دقیق در origin محلیِ lab مجاز است. همهٔ POSTهای محصول، Auth admin/token/signup و queryهای اضافی مسدودند. این استثنا مجوز اقتصادی یا نوشتن محصول ایجاد نمی‌کند. دو آزمون تازه، خروج واقعیِ SDK و مرز این استثنا را می‌سنجند؛ مجموع آزمون‌های اتصال ۸/۸ موفق، با صفر شکست و skip است. هفت module بررسی syntax می‌شوند. native هنوز اجرا نشده است.

منبع فقط commit `4dcf3713c3ad2507ed1a5bfee42a52b3c17cfb8a` و tree `c96d462d72505f2471c54c8e7e5293fe2b39b3d1` است. profile مستقل `assembled-member-admin`، mode مستقل `assembled-member-admin-v1` و source env مستقل دارد. runtime قدیمی، profileها و pinهای آن و فایل SQL قدیمی ویرایش نمی‌شوند. app از Git archive دقیق می‌آید؛ کل tree checkout باید همان منبع باشد و هشت helper جدید با قرارداد جدا مهر می‌شوند. اصل helperها و SQL روی دیسک نیز پیش از اثر hash می‌شوند.

bootstrap، ۱۷ فایل manifest مرحلهٔ اول را حفظ می‌کند و migration موجودِ `20261003094327_member_investment_scope_reviews.sql` را برای صفحهٔ واقعی دارایی می‌افزاید؛ کد SQL تغییر نکرده است. تصاویر، lifecycle، GoTrue/PostgREST/PostgreSQL tmpfs و Chrome همان موارد ثابت موجودند. زیرساخت، package، ابزار یا مدل تازه نصب/فعال نمی‌شود. هزینه CI اندازه‌گیری نشده است.

پوششِ run آینده: دو POST مالی ساختگی و یک POST رضایت با intent محفوظ، GET مستقل نسخه و null، جدایی حساب دوم، basis دقیق برای مشاور مجاز و رد عضو/admin نامرتبط؛ ناوبری anchor واقعی dashboard→دارایی→dashboard→مشاوره در viewport390؛ سپس SDK/JWT هفت‌ستونی legacy، RLS، حالت منبع تأییدنشده، حق خدمت متصل‌نشده، نوشتن بسته، تغییر هویت، خروج و پاکسازی. فقط Auth signout صریح از مرورگر مجاز است؛ POST محصول از مرورگر صفر می‌ماند. هیچ توصیه‌ای منتشر نمی‌شود.

نتیجهٔ موفقِ احتمالی `PASS_BOUNDED_ASSEMBLED_NATIVE` است؛ `fullAssembledAcceptance=NOT_ESTABLISHED`. **جمع‌بندی منتشرشدهٔ نسخه‌دار و بازیابی UI با پاسخ ثبت نامعلوم هنوز در این ترکیب سنجیده نشده‌اند**؛ مالکشان B است. این خروجی جای رسید کامل هفت‌گروهی، نصب اصلی یا پذیرش آرش را نمی‌گیرد.

قرارداد driver دقیق v2:

`4c661f7d3cf8aa75f1185e7496c35a4ca766501af9be25d227fbab2e75160a9c`

capsule `assembled-native-bounded-v2.tar` شامل `overlay-v2/` با نام `overlay/` و materializer و همین راهنماست. پس از بازبینی source و تخصیص صریحِ محیط **جدا** و fixture توسط هماهنگ‌کننده، همان هماهنگ‌کننده اجرا می‌کند؛ آرش پیام یا فایل بین چت‌ها منتقل نمی‌کند. `$ASSEMBLED_REPO` و `$ROOT_ALLOCATION_ID` از تخصیص واقعی می‌آیند. شرط واقعیِ Linux CI موجود حفظ شده است؛ فلگ‌ها نباید برای دورزدن آن جعل شوند.

```bash
python3 apply-overlay.py --bundle ./overlay --repo "$ASSEMBLED_REPO" --driver-contract-sha256 4c661f7d3cf8aa75f1185e7496c35a4ca766501af9be25d227fbab2e75160a9c
```

در checkout جدا با dependencies موجود:

```bash
cd "$ASSEMBLED_REPO"
P01_P03_ASSEMBLED_NATIVE_SOURCE_SHA=4dcf3713c3ad2507ed1a5bfee42a52b3c17cfb8a node --import tsx scripts/testing/consultation-tickets/assembled-native.mjs --execute --allocation-id "$ROOT_ALLOCATION_ID" --driver-contract-sha256 4c661f7d3cf8aa75f1185e7496c35a4ca766501af9be25d227fbab2e75160a9c
```

materializer فقط فایل تازه می‌نویسد؛ collision یا کپی ناقص نیازمند بازخوانی است و overwrite خودکار ندارد. driver بدون تخصیص/hash صریح اجرا نمی‌شود. هر POST نامعلوم کل run را متوقف می‌کند؛ تکرار خودکار ندارد. cleanup فقط منابع attested متعلق به run را برمی‌دارد؛ intent/session خصوصی عمومی نمی‌شوند. در ساخت این بسته هیچ native، Docker، شبکه، Auth، SQL، حساب یا Production اجرا نشده است. شاهدهای آماده‌سازی در `integration-delivery-v2.json` و کد آزمون اتصال‌اند.
