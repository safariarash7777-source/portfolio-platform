// P03 test-only derivative; exact request-page browser mode only.
// Shared native Next gateway. Fixed pf10/p09 profiles only; no mock responses.
import http from 'node:http';
import {assembledBrowserReadAllowed} from './assembled-native-profile.mjs';
const origin='http://localhost:32189';
export function gatewayProfile(profile){
 if(profile!=='assembled-member-admin')throw Error('p03_ticket_native_unknown_profile');
 return {"identityPath": "/__p03_ticket_native_identity", "routes": ["/api/consultation", "/api/consultation/roster", "/api/consultation/replies", "/api/consultation/tickets", "/api/consultation/ticket-attempts", "/api/portfolio/holdings", "/api/portfolio/debts", "/api/portfolio/holdings/scope", "/api/personal-finance/cash-flow", "/api/personal-finance/goals"]};
}
// Opt-in p09 page only. Raw paths are checked before URL normalization.
export function browserRequestAllowed(value,method='GET',acceptance='ticket'){
 if(acceptance==='assembled-member-admin-v1')return assembledBrowserReadAllowed(value,method,'member')||assembledBrowserReadAllowed(value,method,'advisor');
 if(!['ticket','feedback-reader-v1','assembled-member-admin-v1'].includes(acceptance)||!['GET','HEAD'].includes(method)||typeof value!=='string')return false;
 try{
  const url=new URL(value,origin);if(url.origin!==origin||url.username||url.password||url.hash)return false;
  const raw=value.startsWith(origin)?value.slice(origin.length):value;
  if(!raw.startsWith('/')||raw.startsWith('//'))return false;
  if(/%(?:2e|2f|5c|25|00)/i.test(raw.split('?')[0]))return false;
  const path=decodeURIComponent(raw.split('?')[0]);
  if(/[\\%\u0000-\u0020]/.test(path)||path.split('/').some(x=>x==='.'||x==='..'))return false;
  const pages=acceptance==='feedback-reader-v1'?['/dashboard/consultation','/admin/consultation']:['/dashboard/consultation/requests','/admin/consultation/requests'];
  if(pages.includes(path)){
   const seen=new Set();for(const [key,v] of url.searchParams){if(seen.has(key))return false;seen.add(key);if((acceptance==='feedback-reader-v1'?['relation']:['relation','request']).includes(key)){if(!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(v))return false;}else if(key==='_rsc'){if(!/^[a-zA-Z0-9_-]{1,100}$/.test(v))return false;}else return false;}
   return !url.searchParams.has('request')||url.searchParams.has('relation');
  }
  if(path==='/_next/image')return [...url.searchParams.keys()].length===3&&url.searchParams.get('url')==='/brand/mark.png'&&/^(32|48|64|96|128|256|384|640|750|828|1080|1200|1920|2048|3840)$/.test(url.searchParams.get('w')??'')&&url.searchParams.get('q')==='75';
  for(const [key,v] of url.searchParams)if(key!=='v'||!/^\d{1,20}$/.test(v))return false;
  if(['/fonts/Vazirmatn-Variable.woff2','/fonts/Pelak-Bold.woff2','/fonts/Pelak-ExtraBold.woff2','/fonts/Pelak-Black.woff2','/brand/mark.png'].includes(path))return !url.search;
  return path.startsWith('/_next/static/')&&/^\/[a-zA-Z0-9_./()[\]@-]+$/.test(path);
 }catch{return false;}
}
export async function startNativeAuthGateway(profile){
 const config=gatewayProfile(profile);
 const browserMode=process.env.NATIVE_AUTH_BROWSER_MODE==='true';
 const acceptance=process.env.NATIVE_AUTH_ACCEPTANCE_MODE??'ticket';
 if(!['ticket','feedback-reader-v1','assembled-member-admin-v1'].includes(acceptance)||(acceptance!=='ticket'&&!browserMode))throw Error('p03_feedback_gateway_mode');
 if((process.env.NATIVE_AUTH_BROWSER_MODE!==undefined&&!['true','false'].includes(process.env.NATIVE_AUTH_BROWSER_MODE))||(browserMode&&profile!=='assembled-member-admin'))throw Error('p09_browser_gateway_mode');
 if(process.platform!=='linux'||process.env.NATIVE_AUTH_PROFILE!==profile||process.env.NATIVE_AUTH_ORIGIN!==origin||!/^[a-f0-9]{40}$/.test(process.env.NATIVE_AUTH_SHA??''))throw Error('pf10_native_gateway_environment');
 const {default:next}=await import('next');
 const {default:sourceConfig}=await import('./next.config.js');
 // Keep the source config; suppress dev request/fetch URL logs containing correlation tokens.
 const app=next({dev:true,hostname:'127.0.0.1',port:32189,conf:{...sourceConfig,logging:false}});
 await app.prepare();const handle=app.getRequestHandler(),allowed=new Set(config.routes);
const server=http.createServer((req,res)=>{
 const path=new URL(req.url,origin).pathname;
 if(path===config.identityPath){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({profile,runId:process.env.NATIVE_AUTH_RUN,sha:process.env.NATIVE_AUTH_SHA}));return;}
 if(path.startsWith('/auth/v1/')||path.startsWith('/rest/v1/')){
  const upstream=http.request({hostname:'127.0.0.1',port:32190,path:req.url,method:req.method,headers:req.headers},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res);});
  upstream.on('error',()=>{if(!res.headersSent)res.writeHead(502);res.end();});req.pipe(upstream);return;
 }
 if(!allowed.has(path)&&!(browserMode&&browserRequestAllowed(req.url,req.method,acceptance))){res.writeHead(404);res.end();return;}
 void handle(req,res);
});
server.listen(32189,'127.0.0.1');
process.on('SIGTERM',()=>{server.close();void app.close();});
}
if(process.argv[1]&&new URL(import.meta.url).pathname===process.argv[1])await startNativeAuthGateway(process.env.NATIVE_AUTH_PROFILE);
