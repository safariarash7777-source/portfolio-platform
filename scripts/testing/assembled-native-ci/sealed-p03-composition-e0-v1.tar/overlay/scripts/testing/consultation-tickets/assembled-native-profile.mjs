// Detached preparation only. This module cannot start containers, Auth or Next.
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

export const mode = 'p03-composition-e0-v1';
export const candidateCommit = 'e0b930927563d7f9f6d79e848917c4ba0d77ed6f';
export const candidateTree = 'c6c67f2a78cd2cf672cf4f489f81e7f14cb041da';
export const origin = 'http://localhost:32189';
export const sourceContractSha256 = 'f9bcbfd29a118e02304544124ef41ef4c43bb837eef9956b9cefad7312b74047';
const check = (value, code) => { if (!value) throw Error(code); };
const hash = value => createHash('sha256').update(value).digest('hex');
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const exactKeys = (value, names, code) => check(record(value) && Object.keys(value).sort().join('\0') === [...names].sort().join('\0'), code);
const digest = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const uuid = value => /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(value);
const freeze = value => { if (value && typeof value === 'object') { for (const item of Object.values(value)) freeze(item); Object.freeze(value); } return value; };

export function loadSourceContract(raw = readFileSync(new URL('./assembled-native-source.json', import.meta.url))) {
  check(hash(raw) === sourceContractSha256, 'assembled_source_contract_changed');
  const value = JSON.parse(raw.toString('utf8'));
  check(value.mode === mode && value.candidateCommit === candidateCommit && value.candidateTree === candidateTree && value.origin === origin, 'assembled_source_identity');
  return freeze(value);
}
export const sourceContract = loadSourceContract();

export function validateSourceObservation(observed) {
  exactKeys(observed, ['commit', 'tree', 'objects', 'files'], 'assembled_observation_shape');
  check(observed.commit === candidateCommit && observed.tree === candidateTree, 'assembled_exact_candidate_required');
  exactKeys(observed.objects, Object.keys(sourceContract.sourceObjects), 'assembled_source_object_set');
  for (const [path, object] of Object.entries(sourceContract.sourceObjects)) check(observed.objects[path] === object, 'assembled_source_object_changed');
  check(Array.isArray(observed.files) && observed.files.length === sourceContract.files.length, 'assembled_source_file_set');
  const paths = new Set();
  for (const file of observed.files) {
    exactKeys(file, ['path', 'blob', 'bytes', 'sha256'], 'assembled_source_file_shape');
    const expected = sourceContract.files.find(item => item.path === file.path);
    check(expected && !paths.has(file.path) && file.blob === expected.blob && file.bytes === expected.bytes && file.sha256 === expected.sha256, 'assembled_source_file_changed');
    paths.add(file.path);
  }
  return freeze({ status: 'PASS_SOURCE_READBACK_ONLY', mode, candidateCommit, candidateTree,
    sourceContractSha256, objectsVerified: Object.keys(observed.objects).length,
    filesVerified: observed.files.length, nativeExecution: 'NOT_RUN', integration: 'NOT_APPLIED',
    fixtureWrites: 'NOT_ALLOCATED', targetInstall: 'NOT_APPLIED', arashAcceptance: 'UNOBSERVED' });
}

// Exact immutable Git object reads only. No checkout/fetch/process launch beyond Git.
export function readCandidate(repo, requestedCommit = candidateCommit) {
  check(requestedCommit === candidateCommit, 'assembled_exact_candidate_required');
  const git = args => {
    try { return execFileSync('git', args, { cwd: repo, stdio: ['ignore', 'pipe', 'pipe'], timeout: 15000, maxBuffer: 2 * 1024 * 1024 }); }
    catch { throw Error('assembled_git_read_failed'); }
  };
  const text = args => git(args).toString('utf8').trim();
  const observation = { commit: text(['rev-parse', requestedCommit + '^{commit}']),
    tree: text(['rev-parse', requestedCommit + '^{tree}']), objects: {}, files: [] };
  for (const path of Object.keys(sourceContract.sourceObjects)) observation.objects[path] = text(['rev-parse', requestedCommit + ':' + path]);
  for (const { path } of sourceContract.files) {
    const raw = git(['show', requestedCommit + ':' + path]);
    observation.files.push({ path, blob: text(['rev-parse', requestedCommit + ':' + path]), bytes: raw.length, sha256: hash(raw) });
  }
  return validateSourceObservation(observation);
}

// Browser navigation policy for the new profile only. Fixture API writes require
// a separate reviewed runner allocation and never become automatic page writes.
export function assembledBrowserReadAllowed(value, method = 'GET', actor = 'member') {
  if (!['GET', 'HEAD'].includes(method) || !['member', 'advisor'].includes(actor) || typeof value !== 'string') return false;
  try {
    const url = new URL(value, origin);
    if (url.origin !== origin || url.username || url.password || url.hash) return false;
    const raw = value.startsWith(origin) ? value.slice(origin.length) : value;
    if (!raw.startsWith('/') || raw.startsWith('//')) return false;
    const rawPath = raw.split('?')[0];
    if (/%(?:2e|2f|5c|25|00)/i.test(rawPath)) return false;
    const path = decodeURIComponent(rawPath);
    if (/[\\%\u0000-\u0020]/.test(path) || path.split('/').some(x => x === '.' || x === '..')) return false;
    const root = actor === 'member' ? '/dashboard/consultation' : '/admin/consultation';
    const consultation = [root, root + '/requests'].includes(path);
    if (consultation || (actor === 'member' && ['/dashboard', '/dashboard/holdings'].includes(path))) {
      const keys = new Set();
      for (const [key, val] of url.searchParams) {
        if (keys.has(key)) return false;
        keys.add(key);
        if (key === '_rsc') { if (!/^[a-zA-Z0-9_-]{1,100}$/.test(val)) return false; }
        else if (consultation && (key === 'relation' || (path.endsWith('/requests') && key === 'request'))) { if (!uuid(val)) return false; }
        else return false;
      }
      return !keys.has('request') || keys.has('relation');
    }
    if (['/fonts/Vazirmatn-Variable.woff2', '/fonts/Pelak-Bold.woff2', '/fonts/Pelak-ExtraBold.woff2', '/fonts/Pelak-Black.woff2', '/brand/mark.png'].includes(path)) return !url.search;
    if (path === '/_next/image') {
      const keys = [...url.searchParams.keys()];
      return keys.length === 3 && new Set(keys).size === 3 && keys.every(key => ['url', 'w', 'q'].includes(key)) && url.searchParams.get('url') === '/brand/mark.png' && /^(32|48|64|96|128|256|384|640|750|828|1080|1200|1920|2048|3840)$/.test(url.searchParams.get('w') ?? '') && url.searchParams.get('q') === '75';
    }
    if (!path.startsWith('/_next/static/') || !/^\/[a-zA-Z0-9_./()[\]@-]+$/.test(path)) return false;
    const keys = [...url.searchParams.keys()];
    return keys.length === 0 || (keys.length === 1 && keys[0] === 'v' && /^\d{1,20}$/.test(url.searchParams.get('v')));
  } catch { return false; }
}

export const checks = Object.freeze([
  'exact-whole-assembly-and-runtime-identity',
  'member-dashboard-to-versioned-financial-dossier',
  'member-admin-consent-and-versioned-summary',
  'actual-assembled-legacy-self-read',
  'composed-read-history-and-identity-invalidation',
  'unknown-write-no-replay-and-human-boundaries',
  'owned-cleanup-and-sanitized-receipt',
]);

// This validates a future native receipt, never creates or substitutes for one.
// Expected driver/allocation identities must come from the coordinator's gate.
export function validateNativeReceipt(value, expectedDriverSha256, expectedAllocationId) {
  check(digest(expectedDriverSha256) && uuid(expectedAllocationId ?? ''), 'assembled_external_gate_required');
  exactKeys(value, ['schemaVersion', 'mode', 'status', 'candidateCommit', 'candidateTree', 'sourceContractSha256', 'driverContractSha256', 'allocationId', 'runtime', 'checks', 'proof', 'cleanup', 'targetInstall', 'arashAcceptance'], 'assembled_receipt_shape');
  check(value.schemaVersion === 'assembled-native-receipt.v1' && value.mode === mode && value.status === 'PASS' && value.candidateCommit === candidateCommit && value.candidateTree === candidateTree && value.sourceContractSha256 === sourceContractSha256 && value.driverContractSha256 === expectedDriverSha256 && value.allocationId === expectedAllocationId, 'assembled_receipt_identity');
  exactKeys(value.runtime, ['target', 'origin', 'runId', 'images', 'tmpfs', 'databaseMarkerVerified', 'sourceArchiveVerified', 'independentActorBindingsVerified'], 'assembled_runtime_shape');
  check(value.runtime.target === 'OWNED_ISOLATED_LINUX_ONLY' && value.runtime.origin === origin && uuid(value.runtime.runId), 'assembled_runtime_target');
  exactKeys(value.runtime.images, Object.keys(sourceContract.infrastructure.images), 'assembled_runtime_images');
  for (const [role, image] of Object.entries(sourceContract.infrastructure.images)) check(value.runtime.images[role] === image, 'assembled_runtime_image_changed');
  for (const key of ['tmpfs', 'databaseMarkerVerified', 'sourceArchiveVerified', 'independentActorBindingsVerified']) check(value.runtime[key] === true, 'assembled_runtime_unverified');
  check(Array.isArray(value.checks) && value.checks.length === checks.length, 'assembled_receipt_checks');
  const seen = new Set();
  for (const item of value.checks) {
    exactKeys(item, ['name', 'status'], 'assembled_check_shape');
    check(checks.includes(item.name) && item.status === 'PASS' && !seen.has(item.name), 'assembled_receipt_checks');
    seen.add(item.name);
  }
  const positive = ['financialVersionReceiptsReadBack', 'financialNullsPreserved', 'consentIndependentOfPurchase', 'exactAuthorizedDossierVersion', 'sevenLegacyColumnsSameVerifiedJwt', 'ownForeignRlsVerified', 'legacySourceUnverified', 'serviceRightNotConnected', 'productWritesClosed', 'historySurvivesIndependentRead', 'identityClearsPrivateSurfaces', 'signoutClearsPrivateSurfaces', 'unknownIntentAndReceiptLookup', 'originalHistoryUnchangedAfterRead'];
  const zero = ['advisorForeignSideGets', 'lateIdentityGets', 'domAutomaticPosts', 'replayedPosts', 'unknownOutcomes', 'privateStorageHits', 'privateUrlHits', 'modelCalls', 'externalFinancialDataRequests'];
  exactKeys(value.proof, [...positive, ...zero, 'canonicalReceiptDigests'], 'assembled_proof_shape');
  for (const key of positive) check(value.proof[key] === true, 'assembled_proof_incomplete');
  for (const key of zero) check(value.proof[key] === 0, 'assembled_proof_nonzero');
  check(Array.isArray(value.proof.canonicalReceiptDigests) && value.proof.canonicalReceiptDigests.length >= 2 && value.proof.canonicalReceiptDigests.length <= 8 && value.proof.canonicalReceiptDigests.every(digest) && new Set(value.proof.canonicalReceiptDigests).size === value.proof.canonicalReceiptDigests.length, 'assembled_canonical_receipts_required');
  exactKeys(value.cleanup, ['resourcesRemoved', 'contextsClosed', 'processesStopped', 'ownedTempRemoved', 'ownerMarkerVerified'], 'assembled_cleanup_shape');
  check(Object.values(value.cleanup).every(item => item === true), 'assembled_cleanup_incomplete');
  check(value.targetInstall === 'NOT_APPLIED' && value.arashAcceptance === 'UNOBSERVED', 'assembled_acceptance_boundary');
  return freeze(structuredClone(value));
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    check(process.argv.length === 3, 'assembled_repo_argument_required');
    console.log(JSON.stringify(readCandidate(process.argv[2])));
  } catch (error) {
    console.error(JSON.stringify({ status: 'FAIL_SOURCE_READBACK', reason: /^assembled_[a-z_]+$/.test(error?.message ?? '') ? error.message : 'assembled_readback_failed', nativeExecution: 'NOT_RUN', automaticRetry: false }));
    process.exitCode = 1;
  }
}
