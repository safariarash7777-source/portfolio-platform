// Versioned composition in the existing root-owned driver/lifecycle only.
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {runNativeAuthProfile,assembledCandidateSha} from './assembled-auth-runtime.mjs';
import {preflight,cleanup,browserFailureCode} from './browser.mjs';
import {composeExistingMemberCase,recordPass} from './composition-browser-case.mjs';
import {compositionNativeChecks,canonicalFinancialHash} from './composition-contract.mjs';
import {verifyOverlayGate} from './assembled-overlay-gate.mjs';
const mode='p03-composition-e0-v1';
const check=(value,code)=>{if(!value)throw Error('p03_composition_'+code);};
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');

async function exercise(ctx,state){
 await ctx.setWriteRelease(true); // only the already-attested owned server process
 const binding=await ctx.attestComposition();
 const flow=await composeExistingMemberCase({...ctx,compositionBinding:binding},state);
 const summary=flow.compositionSummary,fresh=flow.compositionFresh,basis=flow.compositionBasis;
 const counts=flow.compositionCounts,isolation=flow.compositionIsolation;
 const auth=ctx.observedAuth(),extra=[];
 const pass=(name,evidence)=>{check(compositionNativeChecks.includes(name)&&!extra.includes(name),'check_identity');extra.push(name);ctx.pass(name,evidence);};
 check(summary.exactTicketLink===true&&summary.version===1&&summary.requestVersion===3&&/^[a-f0-9]{64}$/.test(summary.contentHash),'summary_witness');
 pass('composition-summary-published-exact-link',{summaryVersion:summary.version,ticketLinkVersion:summary.requestVersion,exactReferenceHash:summary.contentHash,syntheticOwnerOnly:true,writeMode:summary.writeMode});
 const statuses=summary.original.filter(r=>r.actionKey!==null).map(r=>r.status).sort();
 check(statuses.join()===['doing','done'].sort().join()&&summary.original.length===3&&summary.replyReceipt?.version===1,'question_feedback_witness');
 pass('composition-question-reply-and-feedback',{actionStatuses:statuses,feedbackRows:summary.original.length,replyVersion:summary.replyReceipt.version,rowsDigest:digest(summary.original)});
 check(fresh.freshDom.length===2&&fresh.freshDom.every(r=>r.realLogout&&r.newPasswordSdkSession&&r.actualReload&&r.getOnly),'fresh_dom_witness');
 pass('composition-fresh-summary-dom-get-only',{actors:2,newPasswordSdkSessions:true,actualReload:true,getOnly:true});
 check(summary.beforeFinancialHash===summary.afterFinancialHash&&fresh.beforeFinancialHash===summary.beforeFinancialHash&&fresh.originalRowsStable===true,'stable_feedback_witness');
 pass('composition-feedback-stable-before-basis-change',{beforeHash:summary.beforeFinancialHash,afterHash:summary.afterFinancialHash,originalRowsStable:true});
 check(basis.afterFeedbackProof&&basis.realHoldingVersion===2&&basis.replyReadOnlyReason==='basis_changed'&&basis.deniedReplyStatus===409&&basis.originalSummaryBasisRetained,'basis_witness');
 pass('composition-financial-basis-change-readonly',{holdingVersion:2,afterFeedbackProof:true,readOnlyReason:basis.replyReadOnlyReason,replyDeniedStatus:409,oldBasisRetained:true});
 check(isolation&&isolation.owner===403&&isolation.b===403&&isolation.admin===403&&isolation.memberHistoryRetained===true,'isolation_witness');
 pass('composition-isolation-revocation-history',{unrelatedMemberDenied:true,unrelatedAdminDenied:true,revokedAdvisorDenied:true,memberHistoryRetained:true});
 check(counts.total===26&&counts.positive===24&&counts.denied===2&&counts.unresolved===0&&!counts.stopped&&auth.createAttempts===4&&auth.passwordAttempts===counts.authPassword&&auth.passwordAttempts===9&&auth.logoutAttempts===counts.authLogout&&auth.logoutAttempts===4&&auth.negativeRpcAttempts===counts.negativeRpc&&auth.negativeRpcAttempts===1,'actual_auth_counts');
 pass('composition-auth-api-cdp-counts',{productPostAttempts:counts.total,positive:counts.positive,denied:counts.denied,unresolved:counts.unresolved,authCreate:auth.createAttempts,authPassword:auth.passwordAttempts,authLogout:auth.logoutAttempts,negativeRpc:auth.negativeRpcAttempts,replayedPosts:0});
 const database=ctx.observeCompositionDatabase();
 check(database.sessions[0].id===summary.sessionId&&database.sessions[0].contentHash===summary.contentHash&&database.relationships[0].id===summary.replyReceipt.command.relationshipId,'independent_db_link');
 const removed=await cleanup(state);state.cleaned=true;recordPass(state,'owned-browser-cleanup',removed);
 check(state.checks.length===11&&removed.processStopped&&removed.contextsClosed&&removed.ownedTempRemoved,'browser_cleanup');
 pass('composition-owned-browser-cleanup',{ownerId:removed.ownerId,processStopped:removed.processStopped,contextsClosed:removed.contextsClosed,ownedTempRemoved:removed.ownedTempRemoved});
 const loss=name=>{const r=state.checks.find(x=>x.name===name);check(r?.status==='PASS','loss_witness_missing');return r;};
 const commandLoss=loss('unconfirmed-command-destroy-and-server-intent-get-only'),preparationLoss=loss('unknown-preparation-destroy-no-command');
 const proof={schema:'p03-composition-observed.v1',appSha:binding.appSha,appTree:binding.appTree,allocationId:binding.allocationId,runId:binding.runId,
  sourceBindingDigest:digest(binding),sameRelationship:true,actors:binding.authCreatedIds.length,
  summary, freshDom:fresh.freshDom,basisChange:basis,isolation,counts,auth,databaseDigest:digest(database),
  commandLoss,preparationLoss,browserChecks:state.checks.map(x=>({name:x.name,status:x.status})),
  unknownScope:'P03-ticket-only',p09UnknownSave:'NOT_COVERED_MISSING_JOURNAL',p09HistoricalAcceptanceTransferred:false,
  modelCalls:0,workbookPosts:0,productServiceRight:'NOT_CONNECTED',targetInstall:'NOT_APPLIED',arashAcceptance:'UNOBSERVED'};
 return {composition:proof,browser:{status:'PASS',driverVersion:'1.64.1',sourceExecutable:'/opt/google/chrome/chrome',sourceSha256:state.sourceSha256,executable:state.executable,ownedTemp:state.local,ownerId:state.owner,chromeVersion:state.chromeVersion,chromeSha256:state.chromeSha256,closure:state.closure,checks:state.checks,
  pageClosed:flow.pageClosed,contextClosed:flow.contextClosed,freshLoginVerified:flow.freshLoginVerified,reloadGetOnly:flow.reloadGetOnly,automaticTicketPosts:flow.automaticTicketPosts,privateStorageHits:flow.privateStorageHits,privateUrlHits:flow.privateUrlHits,cacheAuditComplete:flow.cacheAuditComplete,cleanup:removed}};
}

export async function runAssembledNative(){
 let state;
 try{
  verifyOverlayGate(process.argv.slice(2));state=await preflight();recordPass(state,'browser-preflight-before-provision',{sourceSha256:state.sourceSha256,noBrowserDownload:true});
  await runNativeAuthProfile('consultation-ticket',ctx=>exercise(ctx,state),{browserMode:true,acceptance:mode});
 }finally{if(state&&!state.cleaned)await cleanup(state);}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))runAssembledNative().catch(error=>{console.error('P03_ASSEMBLED_FAILURE '+JSON.stringify({status:'FAIL',reason:/^(?:p03_composition|assembled|pf10_native|p09_browser)_[a-z0-9_]+$/.test(error?.message??'')?error.message:browserFailureCode(error),automaticRetry:false,targetInstall:'NOT_APPLIED',productServiceRight:'NOT_CONNECTED'}));process.exitCode=1;});
