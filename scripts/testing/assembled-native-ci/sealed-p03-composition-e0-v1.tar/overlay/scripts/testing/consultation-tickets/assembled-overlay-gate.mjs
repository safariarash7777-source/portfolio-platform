import { readFileSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolve, dirname } from 'node:path';
import { candidateCommit, candidateTree, readCandidate, sourceContract } from './assembled-native-profile.mjs';
const here = dirname(fileURLToPath(import.meta.url)), root = resolve(here, '../../..');
const check = (v, code) => { if (!v) throw Error(code); };
const hash = value => createHash('sha256').update(value).digest('hex');
export function verifyOverlayGate(args) {
  check(process.platform === 'linux' && process.env.CI === 'true' && process.env.GITHUB_ACTIONS === 'true', 'assembled_existing_linux_ci_required');
  check(args.length === 5 && args[0] === '--execute' && args[1] === '--allocation-id' && args[3] === '--driver-contract-sha256' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(args[2]) && /^[a-f0-9]{64}$/.test(args[4]), 'assembled_explicit_gate_required');
  const raw = readFileSync(resolve(here, 'assembled-overlay.json'));
  check(hash(raw) === args[4], 'assembled_driver_contract_changed');
  const contract = JSON.parse(raw);
  check(contract.schemaVersion === 'assembled-overlay.v1' && contract.candidateCommit === candidateCommit && contract.candidateTree === candidateTree && contract.coverage === 'BOUNDED_P03_COMPOSITION' && contract.fullAssembledAcceptance === 'NOT_ESTABLISHED', 'assembled_driver_contract_identity');
  const names = ["assembled-auth-gateway.mjs", "assembled-auth-runtime.mjs", "assembled-member-scenario.mjs", "assembled-native-profile.mjs", "assembled-native-source.json", "assembled-native.mjs", "assembled-observer-policy.mjs", "assembled-overlay-gate.mjs", "composition-browser-case.mjs", "composition-contract.mjs", "composition-contract.test.mjs", "composition-member-phase.mjs", "composition-transport.mjs", "composition-transport.test.mjs"];
  check(Array.isArray(contract.files) && contract.files.length === names.length, 'assembled_overlay_file_set');
  const seen = new Set();
  for (const pin of contract.files) {
    check(names.some(name => pin.path === 'scripts/testing/consultation-tickets/' + name) && !seen.has(pin.path), 'assembled_overlay_path');
    seen.add(pin.path);
    const path = resolve(root, pin.path), stat = lstatSync(path), body = readFileSync(path);
    check(stat.isFile() && !stat.isSymbolicLink() && stat.nlink === 1 && body.length === pin.bytes && hash(body) === pin.sha256, 'assembled_overlay_bytes');
  }
  const git = args => { try { return execFileSync('git', args, { cwd: root, stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8', timeout: 15000 }).trim(); } catch { throw Error('assembled_checkout_read_failed'); } };
  check(git(['rev-parse', 'HEAD']) === candidateCommit && git(['rev-parse', 'HEAD^{tree}']) === candidateTree && git(['status', '--porcelain', '--untracked-files=no']) === '', 'assembled_checkout_not_exact');
  git(['diff', '--exit-code', '--no-ext-diff', '--no-textconv', 'HEAD', '--']);
  readCandidate(root);
  const scope = 'supabase/migrations/20261003094327_member_investment_scope_reviews.sql';
  check(Array.isArray(contract.additionalBootstrap) && contract.additionalBootstrap.length === 2 && contract.additionalBootstrap[0].path === scope && contract.additionalBootstrap[1].path === 'scripts/testing/consultation-tickets/owned-fixture.sql', 'assembled_extra_bootstrap_set');
  // Disk SQL/helper bytes used by the lifecycle must equal the frozen Git source.
  for (const pin of [...sourceContract.files, ...contract.additionalBootstrap]) {
    const body = readFileSync(resolve(root, pin.path));
    check(body.length === pin.bytes && hash(body) === pin.sha256, 'assembled_working_source_changed');
  }
  process.env.ASSEMBLED_NATIVE_ALLOCATION_ID = args[2];
  // No SQL, Docker, Auth, fetch, package install or model operation occurs here.
  return { status: 'PASS_OVERLAY_PREFLIGHT_ONLY', allocationId: args[2], driverContractSha256: args[4], nativeExecution: 'NOT_RUN' };
}
