// GENERATED from the reviewed v2b browserCase function; not a parallel runner.
import {randomUUID,createHash} from 'node:crypto';
import {origin,browserChecks} from './native-auth-runtime.mjs';
import {browserDestination,browserFailureCode,sdkCookies,storageAudit} from './browser.mjs';
import {bindCompositionContext,compositionSummaryPhase,compositionFreshSummaryRead,compositionBasisChange} from './composition-member-phase.mjs';
import {inspectMemberNavigation} from './assembled-member-scenario.mjs';
const endpoint='/api/consultation/tickets';
const check=(v,code)=>{if(!v)throw Error(code);};
const digest=v=>createHash('sha256').update(v).digest('hex');
const quote=v=>"'"+String(v).replaceAll("'","''")+"'";
const memberPath='/dashboard/consultation/requests',advisorPath='/admin/consultation/requests';
export function recordPass(s,name,evidence={}){check(browserChecks.includes(name)&&!s.checks.some(x=>x.name===name),'p09_browser_check_identity');const item={name,status:'PASS',...evidence};s.checks.push(item);console.log('P03_TICKET_BROWSER_CHECK '+JSON.stringify(item));}
export async function browserCase(s,ctx,composition=null){
 if(composition!==null)check(composition.ctx===ctx,'p03_composition_shared_context');
 let compositionSummary=null,compositionBasis=null,compositionFresh=null,compositionIsolation=null;
 const {api,sql,users,newSession,pass}=ctx;
 const expect=async(actor,path,body,status=body===undefined?200:201)=>{const response=await api(actor,path,body);check(response.status===status,'p09_browser_real_api_status');return response.value;};
 const period={startOn:'2026-10-01',endOn:'2026-10-31'},date='2026-10-29';
 const position={position_key:'browser-synthetic-cash',manual_label:composition?'Synthetic assembled cash':'Synthetic declared cash',symbol:null,asset_class:'cash',qty:null,unit:'item',as_of:date,title:'Synthetic member declaration',ownership_pct:100,valuation_mode:'declared',declared_value:1000000,currency:'IRT',valuation_source:'Synthetic member declaration only',valuation_as_of:date,valuation_status:'estimated'};
 await expect('a','/api/portfolio/holdings',{base_version:0,client_token:randomUUID(),positions:[position],note:'P03 browser owned fixture only'});
 const source={label:'Synthetic financial statement',observedOn:date};
 await expect('a','/api/personal-finance/cash-flow',{contractVersion:'cash-flow-request.v1',expectedOwnerId:users.a.id,clientToken:randomUUID(),baseVersion:0,payload:{contractVersion:1,period,accountDefinitions:[{accountKey:'bank',label:'Synthetic bank'}],scopeAccountKeys:['bank'],opening:{amountToman:500000,atStartOn:period.startOn,source},coverage:{planned:{status:'unknown',memberAffirmed:false,source:null},actual:{status:'complete',memberAffirmed:true,source}},entries:[{entryKey:'income',basis:'actual',kind:'income',accountKey:'bank',amountToman:100000,occurredOn:'2026-10-02',source,category:null,note:null},{entryKey:'expense',basis:'actual',kind:'expense',accountKey:'bank',amountToman:20000,occurredOn:'2026-10-03',source,category:null,note:null}]}});
 const holdings=await expect('a','/api/portfolio/holdings'),cashflow=await expect('a','/api/personal-finance/cash-flow?'+new URLSearchParams(period));
 check(holdings.positions[0]?.declared_value===1000000&&cashflow.report.actual.closingToman===580000&&cashflow.report.planned.netToman===null,'p09_browser_financial_independent_readback');
 sql(`INSERT INTO public.consultation_advisors(user_id,display_name,enabled,is_owner) VALUES(${quote(users.owner.id)},'Synthetic browser owner',true,true);`);
 const command=async(actor,command)=>expect(actor,'/api/consultation',{contractVersion:'consultation-request.v1',expectedActorId:users[actor].id,clientToken:randomUUID(),command});
 const relation=(await command('a',{kind:'grant',advisorId:users.owner.id,clientLabel:'Synthetic browser member'})).id;
 const parent=await expect('a','/api/consultation?'+new URLSearchParams({...period,relationshipId:relation}));
 check(parent.dossier?.basis?.holdingsVersionId&&parent.dossier.basis.cashFlowVersionId,'p09_browser_nonzero_basis_missing');
 const fingerprint=()=>sql("SELECT jsonb_build_object("+['member_holding_versions','member_holding_positions','member_debt_positions','member_cash_flow_versions','member_cash_flow_entries','member_goals_versions'].map(name=>quote(name)+",(SELECT encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]'),'UTF8')),'hex') FROM public."+name+' r)').join(',')+');');
 const before=fingerprint();let expectedFinalFinancial=before;
 if(composition)await inspectMemberNavigation(ctx,s,ctx.forwardReadOnlyNav);
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-financial-before-write',edge:'before'}));
 ctx.write('browser-financial-before.json',{fingerprint:before,basis:parent.dossier.basis},true);
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-financial-before-write',edge:'after'}));
 pass('browser-owned-nonzero-dossier-real-consent',{holdingsToman:1000000,actualClosingToman:580000,plannedUnknown:true});
 const marker='SYNTHETIC_PRIVATE_BROWSER_MEMBER_BODY',subject='Synthetic browser request',reply='SYNTHETIC_SHARED_BROWSER_ADVISOR_REPLY',followup='SYNTHETIC_PRIVATE_BROWSER_MEMBER_FOLLOWUP';
 const needles=[marker,reply,followup];let posts=0,lost=false,armed=false,original=null,automatic=0,preparationPosts=0,closeCommand=false,closePreparation=false,destroyedCommand=false,destroyedPreparation=false,capturedCommand=null,capturedPreparation=null;
 const pages=[],cache=[],observedLookups=[],http=[],pageErrors=[];
 const history=page=>page.locator('section[aria-label="تاریخچهٔ نسخه‌دار درخواست"]');
 // React mirrors a controlled textarea value into its child text. Playwright
 // 1.64.1's exact label selector includes that nested text; use the actual
 // composer textarea, with normal actionability checks and no forced events.
 const textField=page=>page.locator('form[aria-label="ثبت درخواست یا پیگیری"] textarea');
 const submit=page=>page.getByRole('button',{name:'ثبت آزمایشی با بررسی سرور',exact:true});
 const reload=page=>page.getByRole('button',{name:'بازخوانی بدون ارسال دوباره',exact:true});
 const settle=async(page,condition,code)=>ctx.wait(async()=>{if(s.asyncFailure)throw Error(s.asyncFailure);return condition(page);},code,60);
 const open=async(actor,path,requestId)=>{
  const context=await s.browser.newContext({serviceWorkers:'block',viewport:{width:1440,height:1000}});s.contexts.push(context);
  needles.push(users[actor].session.token,...sdkCookies(users[actor].session.cookie).map(x=>x.value).filter(Boolean));
  await context.addCookies(sdkCookies(users[actor].session.cookie));const page=await context.newPage();pages.push(page);page.on('dialog',dialog=>void dialog.accept());
  page.on('pageerror',error=>pageErrors.push({name:error.name,category:/React is not defined/.test(error.message)?'react_missing':/Maximum update depth/.test(error.message)?'render_loop':/hydration/i.test(error.message)?'hydration':'other_runtime_error'}));
  page.on('response',response=>{const u=new URL(response.url());if(u.pathname.startsWith('/api/')||u.pathname.startsWith('/auth/'))http.push({path:u.pathname,status:response.status()});});
  s.pageDiagnostic=async()=>({stage:s.stage,operation:s.operation,urlClass:[memberPath,advisorPath].includes(new URL(page.url()).pathname)?new URL(page.url()).pathname:'other',http:http.slice(-20),pageErrors:pageErrors.slice(-5),dom:await page.evaluate(()=>({subjectLabels:[...document.querySelectorAll('label')].filter(x=>x.textContent.trim()==='موضوع').length,textLabels:[...document.querySelectorAll('label')].filter(x=>x.textContent.trim()==='متن').length,inputs:[...document.querySelectorAll('input')].map(x=>({disabled:x.disabled,width:x.getBoundingClientRect().width})),fieldsets:[...document.querySelectorAll('fieldset')].map(x=>({disabled:x.disabled})),checking:document.body.textContent.includes('در حال تأیید نشست'),retry:document.body.textContent.includes('بررسی نشست و بازخوانی'),overlay:document.querySelectorAll('nextjs-portal').length}))});
  const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');
  cdp.on('Network.responseReceived',event=>{if([endpoint,'/api/consultation/ticket-attempts'].includes(new URL(event.response.url).pathname))cache.push({disk:!!event.response.fromDiskCache,worker:!!event.response.fromServiceWorker,prefetch:!!event.response.fromPrefetchCache,headers:event.response.headers});});
  await cdp.send('Fetch.enable',{patterns:[{urlPattern:'*',requestStage:'Request'},{urlPattern:origin+endpoint+'*',requestStage:'Response'},{urlPattern:origin+'/api/consultation/ticket-attempts*',requestStage:'Response'}]});
  cdp.on('Fetch.requestPaused',event=>{void(async()=>{
   const request=event.request,u=new URL(request.url),responseStage=event.responseStatusCode!==undefined;
   if(!responseStage){
    const forward=async()=>{
    if(!browserDestination(request.url,request.method)){await cdp.send('Fetch.failRequest',{requestId:event.requestId,errorReason:'BlockedByClient'});return;}
    if(u.pathname===endpoint&&request.method==='POST'){posts++;if(armed){check(!original,'p09_browser_second_armed_post');original=JSON.parse(request.postData);ctx.write('browser-original-intent.json',{input:original},true);}}
    if(u.pathname===endpoint&&request.method==='POST'&&closeCommand){capturedCommand=JSON.parse(request.postData);ctx.write('browser-destroy-command-intent.json',{body:request.postData},true);}
    if(u.pathname==='/api/consultation/ticket-attempts'&&request.method==='POST'){preparationPosts++;if(closePreparation){capturedPreparation=JSON.parse(request.postData);ctx.write('browser-destroy-preparation-intent.json',{body:request.postData},true);}}
    if(u.pathname===endpoint&&request.method==='GET'&&u.searchParams.get('mode')==='lookup')observedLookups.push({requestId:u.searchParams.get('requestId'),clientToken:u.searchParams.get('clientToken')});
    await cdp.send('Fetch.continueRequest',{requestId:event.requestId});
    };
    if(composition)await composition.forwardBrowser(actor,request.url,request.method,request.postData,forward);else await forward();
    return;
   }
   if(composition&&request.method==='POST'&&u.pathname.startsWith('/api/'))composition.recordBrowser(actor,request.url,request.postData,event.responseStatusCode);
   if(closeCommand&&u.pathname===endpoint&&request.method==='POST'&&event.responseStatusCode===201){check(capturedCommand,'p09_browser_destroy_command_missing');closeCommand=false;destroyedCommand=true;await context.close();return;}
   if(closePreparation&&u.pathname==='/api/consultation/ticket-attempts'&&request.method==='POST'&&event.responseStatusCode===201){check(capturedPreparation,'p09_browser_destroy_preparation_missing');closePreparation=false;destroyedPreparation=true;await context.close();return;}
   if(armed&&u.pathname===endpoint&&request.method==='POST'&&event.responseStatusCode===201){check(original&&!lost,'p09_browser_lost_response_identity');lost=true;armed=false;await cdp.send('Fetch.failRequest',{requestId:event.requestId,errorReason:'Aborted'});return;}
   await cdp.send('Fetch.continueResponse',{requestId:event.requestId});
  })().catch(error=>{if(!context.isClosed())s.asyncFailure=browserFailureCode(error);});});
  const url=origin+path+'?'+new URLSearchParams({relation,...(requestId?{request:requestId}:{})});
  s.operation='navigate_'+actor;const document=await page.goto(url,{waitUntil:'domcontentloaded',timeout:120000});check(document?.status()===200,'p09_browser_real_document_not_200');s.operation='document_loaded_'+actor;
  return {page,context};
 };
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-default-page',edge:'before'}));
 s.stage='default_right_page';const first=await open('a',memberPath),page=first.page;
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-default-page',edge:'after'}));
 if(composition){
  check(await submit(page).count()===0&&await textField(page).count()===0,'p03_composition_default_form_exposed');
  const denied={contractVersion:'consultation-ticket-request.v1',expectedActorId:users.a.id,clientToken:randomUUID(),command:{kind:'open',relationshipId:relation,requestId:randomUUID(),baseVersion:0,subject:'Owned closed-cap negative',text:'No command may be sent',recommendation:null}};
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-default-prepare',edge:'before'}));
  const response=await ctx.api('a','/api/consultation/ticket-attempts',denied);check(response.status===503&&response.value.code==='SERVICE_RIGHT_NOT_CONNECTED','p03_composition_default_prepare_not_closed');
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-default-prepare',edge:'after'}));
  recordPass(s,'real-member-page-default-right-closed',{actualDocument:200,formAbsent:true,posts:0,productRight:'NOT_CONNECTED'});
 }else{
 s.operation='default_submit_visible';await submit(page).waitFor({state:'visible',timeout:60000});check(await submit(page).isDisabled(),'p09_browser_product_right_not_closed');
 s.operation='default_subject_fill';await page.getByLabel('موضوع',{exact:true}).fill(subject);s.operation='default_text_fill';await textField(page).fill(marker);
 s.operation='default_text_readback';check(await textField(page).inputValue()===marker&&posts===0,'p09_browser_closed_draft_or_post');
 recordPass(s,'real-member-page-default-right-closed',{actualDocument:200,draftRetained:true,posts:0,productRight:'NOT_CONNECTED'});
 }
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-fixture-apply',edge:'before'}));
 ctx.apply('scripts/testing/consultation-tickets/owned-fixture.sql');
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-fixture-apply',edge:'after'}));
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-fixture-binding',edge:'before'}));
 sql(`INSERT INTO consultation_ticket_fixture.allowed(relationship_id,actor_id) VALUES(${quote(relation)},${quote(users.a.id)}),(${quote(relation)},${quote(users.owner.id)});`);
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-fixture-binding',edge:'after'}));
 await reload(page).click();await settle(page,async()=>await submit(page).count()===1&&!(await submit(page).isDisabled()),'p09_browser_fixture_capability_not_read');
 if(composition){await page.getByLabel('موضوع',{exact:true}).fill(subject);await textField(page).fill(marker);}
 s.stage='live_lost_response';armed=true;await submit(page).click();
 await settle(page,async()=>lost&&(await page.getByText('نتیجهٔ ثبت نامعلوم است؛ ارسال دوباره بسته است. فقط همان تلاش را بازخوانی کنید.',{exact:true}).count())===1,'p09_browser_uncertain_ui_not_seen');
 check(posts===1&&await textField(page).inputValue()===marker,'p09_browser_unknown_draft_or_duplicate');
 check(sql(`SELECT count(*) FROM consultation_ticket_private.events WHERE request_id=${quote(original.command.requestId)}`)==='1','p09_browser_lost_actual_effect_count');
 recordPass(s,'real-201-discard-live-page-one-post',{actualStatus:201,bodyDeliveryAborted:true,pageStayedOpen:!page.isClosed(),ticketPosts:posts,storedEvents:1,httpFulfill:false});
 s.stage='same_attempt_recovery';await reload(page).click();
 await settle(page,async()=>!(await textField(page).inputValue())&&(await history(page).innerText()).includes(marker),'p09_browser_exact_recovery_not_rendered');
 check(posts===1&&observedLookups.some(x=>x.requestId===original.command.requestId&&x.clientToken===original.clientToken),'p09_browser_recovery_not_same_get_only');
 const lookup=await expect('a',endpoint+'?'+new URLSearchParams({mode:'lookup',relationshipId:relation,requestId:original.command.requestId,clientToken:original.clientToken}));
 check(lookup.data.attempt.state==='found'&&lookup.data.attempt.receipt.command.text===marker&&lookup.data.request.data.history.events[0].id===lookup.data.attempt.receipt.id,'p09_browser_independent_receipt_not_exact');
 const eventId=lookup.data.attempt.receipt.id;
 recordPass(s,'same-attempt-get-only-recovery',{sameRequest:true,sameToken:true,sameEventId:eventId,postsAfterRecovery:posts,draftClearedOnlyAfterReadback:true});
 await storageAudit(page,needles);
 const resourceId=original.command.requestId,resourceUrl=page.url();check(new URL(resourceUrl).searchParams.get('request')===resourceId,'p09_browser_resource_url_not_preserved');
 const signedOut=await ctx.post('/auth/v1/logout',{}, {Authorization:'Bearer '+users.a.session.token,apikey:ctx.anon});check([200,204].includes(signedOut.status),'p09_browser_real_signout_failed');
 await first.context.close();check(page.isClosed()&&first.context.isClosed(),'p09_browser_first_context_not_closed');
 const priorToken=users.a.session.token;users.a.session=await newSession('a');check(users.a.session.token!==priorToken,'p09_browser_fresh_sdk_login_missing');
 s.stage='fresh_context';const reopened=await open('a',memberPath,resourceId);let member=reopened.page;
 await history(member).waitFor({state:'visible',timeout:60000});await settle(member,async()=>!(await reload(member).isDisabled()),'p09_browser_fresh_read_not_settled');
 check((await history(member).innerText()).includes(marker)&&posts===1,'p09_browser_fresh_context_not_get_only');
 await member.reload({waitUntil:'domcontentloaded',timeout:120000});await history(member).waitFor({state:'visible',timeout:60000});await settle(member,async()=>!(await reload(member).isDisabled()),'p09_browser_reload_not_settled');
 check((await history(member).innerText()).includes(marker)&&posts===1,'p09_browser_reload_automatic_post');
 recordPass(s,'fresh-sdk-context-and-reload-get-only',{realSignout:true,newPasswordSession:true,sdkGetUser:true,oldContextClosed:true,actualReload:true,postsBefore:1,postsAfter:posts,resourceHistoryOnly:true,unknownIntentAfterDestroy:'SEPARATE_DURABILITY_CRITERIA'});
 s.stage='advisor_reply';let advisor=await open('owner',advisorPath,resourceId);
 await submit(advisor.page).waitFor({state:'visible',timeout:60000});await settle(advisor.page,async()=>!(await submit(advisor.page).isDisabled()),'p09_browser_advisor_not_ready');
 await textField(advisor.page).fill(reply);await submit(advisor.page).click();
 await settle(advisor.page,async()=>(await history(advisor.page).innerText()).includes(reply)&&!(await textField(advisor.page).inputValue()),'p09_browser_advisor_reply_not_read');
 if(composition)compositionSummary=await compositionSummaryPhase(ctx,s,{relation,resourceId,fingerprint});
 await reload(member).click();await settle(member,async()=>(await history(member).innerText()).includes(reply),'p09_browser_member_reply_not_read');
 await textField(member).fill(followup);await submit(member).click();
 await settle(member,async()=>(await history(member).innerText()).includes(followup)&&!(await textField(member).inputValue()),'p09_browser_followup_not_read');
 await reload(advisor.page).click();await settle(advisor.page,async()=>(await history(advisor.page).innerText()).includes(followup),'p09_browser_advisor_followup_not_read');
 check(posts===3&&sql(`SELECT count(*) FROM consultation_ticket_private.events WHERE request_id=${quote(resourceId)}`)===String(composition?4:3),'p09_browser_versions_not_three');
 recordPass(s,'real-advisor-response-and-member-followup',{memberOpen:1,ownerReply:2,memberFollowup:composition?4:3,actualDomSubmits:3,independentSameText:true});
 s.stage='unconfirmed_command_destroy';
 const commandMarker='SYNTHETIC_PRIVATE_DESTROY_BEFORE_COMMAND_CONFIRM';needles.push(commandMarker);
 await member.getByRole('button',{name:'آماده‌کردن درخواست تازه',exact:true}).click();await member.getByLabel('موضوع',{exact:true}).fill('Synthetic destroyed command');await textField(member).fill(commandMarker);
 const beforeDestroyPosts=posts;closeCommand=true;
 try{await submit(member).click();}catch(error){check(destroyedCommand&&/closed/i.test(error.message),'p09_browser_command_destroy_click');}
 await ctx.wait(()=>destroyedCommand&&member.isClosed()&&capturedCommand,'p09_browser_command_context_not_destroyed',60);
 check(posts===beforeDestroyPosts+1,'p09_browser_destroy_command_duplicate');
 const destroyedInput=capturedCommand,preparationId=sql(`SELECT id FROM consultation_ticket_private.prepared_intents WHERE actor_id=${quote(users.a.id)} AND client_token=${quote(destroyedInput.clientToken)}`);
 check(sql(`SELECT count(*) FROM consultation_ticket_private.events WHERE request_id=${quote(destroyedInput.command.requestId)}`)==='1','p09_browser_destroy_command_effect_count');
 const logout2=await ctx.post('/auth/v1/logout',{}, {Authorization:'Bearer '+users.a.session.token,apikey:ctx.anon});check([200,204].includes(logout2.status),'p09_browser_destroy_real_logout');users.a.session=await newSession('a');
 const restoredContext=await open('a',memberPath,destroyedInput.command.requestId);member=restoredContext.page;
 await settle(member,async()=>!(await reload(member).isDisabled()),'p09_browser_destroy_fresh_parent_not_ready');
 const beforeRestorePosts=posts,beforeRestorePreparations=preparationPosts;
 await member.getByRole('button',{name:new RegExp(preparationId)}).click();
 await settle(member,async()=>(await history(member).innerText()).includes(commandMarker)&&(await member.getByText(/در بازخوانی مستقل تطبیق/).count())===1,'p09_browser_destroy_server_original_not_confirmed');
 check(posts===beforeRestorePosts&&preparationPosts===beforeRestorePreparations&&observedLookups.some(x=>x.clientToken===destroyedInput.clientToken&&x.requestId===destroyedInput.command.requestId),'p09_browser_destroy_replayed_post');
 check(sql(`SELECT request_body FROM consultation_ticket_private.prepared_intents WHERE id=${quote(preparationId)}`)===JSON.stringify(destroyedInput),'p09_browser_destroy_server_body_changed');
 recordPass(s,'unconfirmed-command-destroy-and-server-intent-get-only',{real201BeforeBody:true,fullContextDestroyedBeforeConfirmation:true,newPasswordSdkSession:true,serverOriginalBodyTokenRestored:true,explicitSelection:true,commandEvents:1,extraCommandPosts:0,extraPreparationPosts:0});
 s.stage='unknown_preparation_destroy';
 const preparationMarker='SYNTHETIC_PRIVATE_DESTROY_UNKNOWN_PREPARATION';needles.push(preparationMarker);
 await member.getByRole('button',{name:'آماده‌کردن درخواست تازه',exact:true}).click();await member.getByLabel('موضوع',{exact:true}).fill('Synthetic destroyed preparation');await textField(member).fill(preparationMarker);
 const commandsBeforeUnknownPrepare=posts;closePreparation=true;
 try{await submit(member).click();}catch(error){check(destroyedPreparation&&/closed/i.test(error.message),'p09_browser_preparation_destroy_click');}
 await ctx.wait(()=>destroyedPreparation&&member.isClosed()&&capturedPreparation,'p09_browser_preparation_context_not_destroyed',60);
 check(posts===commandsBeforeUnknownPrepare,'p09_browser_unknown_preparation_sent_command');
 const pendingInput=capturedPreparation,pendingPreparationId=sql(`SELECT id FROM consultation_ticket_private.prepared_intents WHERE actor_id=${quote(users.a.id)} AND client_token=${quote(pendingInput.clientToken)}`);
 users.a.session=await newSession('a');const pendingContext=await open('a',memberPath,pendingInput.command.requestId),pendingPage=pendingContext.page;
 await settle(pendingPage,async()=>!(await reload(pendingPage).isDisabled()),'p09_browser_unknown_preparation_fresh_parent');
 const prepareCountBeforeRecovery=preparationPosts;
 await pendingPage.getByRole('button',{name:new RegExp(pendingPreparationId)}).click();
 await settle(pendingPage,async()=>await textField(pendingPage).inputValue()===preparationMarker&&(await pendingPage.getByText(/نبود اثر همین تلاش/).count())===1,'p09_browser_unknown_preparation_original_body_not_loaded');
 check(posts===commandsBeforeUnknownPrepare&&preparationPosts===prepareCountBeforeRecovery,'p09_browser_unknown_preparation_auto_post');
 check(sql(`SELECT count(*) FROM consultation_ticket_private.events WHERE request_id=${quote(pendingInput.command.requestId)}`)==='0','p09_browser_unknown_preparation_created_command');
 await storageAudit(pendingPage,needles);
 recordPass(s,'unknown-preparation-destroy-no-command',{realPreparation201BeforeBody:true,fullContextDestroyed:true,originalBodyFromServer:true,commandEvents:0,automaticPosts:0,explicitRetryOfferedOnly:true});
 if(composition){
  compositionFresh=await compositionFreshSummaryRead(ctx,s,compositionSummary,{relation,fingerprint});
  await advisor.context.close();advisor=await open('owner',advisorPath,resourceId);
  await history(advisor.page).waitFor({state:'visible',timeout:60000});
  check(fingerprint()===before,'p03_composition_pre_basis_financial_change');
  compositionBasis=await compositionBasisChange(ctx,compositionSummary,{relation,position,fingerprint});expectedFinalFinancial=compositionBasis.expectedFinalFinancial;
 }
 const mainContext=await open('a',memberPath,resourceId);member=mainContext.page;await history(member).waitFor({state:'visible',timeout:60000});await settle(member,async()=>!(await reload(member).isDisabled()),'p09_browser_original_case_reopened');
 s.stage='privacy_layout';let audits=0;
 for(const current of [member,advisor.page]){
  for(const width of [1440,390]){await current.setViewportSize({width,height:900});const geometry=await current.evaluate(()=>({viewport:document.documentElement.clientWidth,document:document.documentElement.scrollWidth}));check(geometry.document<=geometry.viewport,'p09_browser_horizontal_overflow');}
  await storageAudit(current,needles);audits++;
 }
 check(cache.length>0&&cache.every(x=>!x.disk&&!x.worker&&!x.prefetch&&Object.entries(x.headers).some(([key,value])=>key.toLowerCase()==='cache-control'&&String(value).includes('private')&&String(value).includes('no-store'))),'p09_browser_private_http_cache');
 recordPass(s,'desktop-mobile-and-private-storage-cache-url',{widths:[1440,390],actualPages:2,storageAudits:audits,privateHits:0,urlHits:0,cacheResponses:cache.length,cacheAuditComplete:true});
 s.stage='disabled_and_revoked';sql(`UPDATE public.consultation_advisors SET enabled=false WHERE user_id=${quote(users.owner.id)};`);
 await reload(advisor.page).click();await settle(advisor.page,async()=>await history(advisor.page).count()===0,'p09_browser_disabled_private_fallback');
 check(!(await advisor.page.locator('body').innerText()).includes(reply),'p09_browser_disabled_private_text');
 sql(`UPDATE public.consultation_advisors SET enabled=true WHERE user_id=${quote(users.owner.id)};`);
 const ownerAgain=await open('owner',advisorPath,resourceId);await history(ownerAgain.page).waitFor({state:'visible',timeout:60000});await settle(ownerAgain.page,async()=>!(await reload(ownerAgain.page).isDisabled()),'p09_browser_owner_reopen_not_settled');
 await command('a',{kind:'revoke',relationshipId:relation});await reload(ownerAgain.page).click();
 await settle(ownerAgain.page,async()=>await history(ownerAgain.page).count()===0,'p09_browser_revoked_private_fallback');
 check(!(await ownerAgain.page.locator('body').innerText()).includes(reply),'p09_browser_revoked_private_text');
 await reload(member).click();await settle(member,async()=>(await history(member).innerText()).includes(followup)&&await submit(member).count()===0,'p09_browser_member_revoke_history');
 const other=await open('b',memberPath,resourceId);await settle(other.page,async()=>!(await other.page.locator('body').innerText()).includes(marker)&&await other.page.locator('section[aria-label="تأیید هویت درخواست"]').count()===1,'p09_browser_other_actor_private_fallback');
 check(await history(other.page).count()===0&&posts===4,'p09_browser_other_actor_or_revoke_post');
 recordPass(s,'real-revoke-and-private-fallback-denial',{disabledAdvisorCleared:true,revokedAdvisorCleared:true,otherMemberDenied:true,memberHistoryVersions:composition?4:3,memberWriteAbsent:true});
 if(composition){
  compositionIsolation={};for(const actor of ['owner','b','admin']){const result=await ctx.api(actor,'/api/consultation?'+new URLSearchParams({...period,relationshipId:relation}));compositionIsolation[actor]=result.status;check(result.status===403,'p03_composition_revoked_isolation');}
  const retained=await expect('a','/api/consultation?'+new URLSearchParams({...period,relationshipId:relation}));
  check(retained.selected.revoked===true&&retained.sessions.some(x=>x.id===compositionSummary.sessionId&&x.contentHash===compositionSummary.contentHash),'p03_composition_revoked_summary_history');
  compositionIsolation.memberHistoryRetained=retained.selected.revoked===true&&retained.sessions.some(x=>x.id===compositionSummary.sessionId&&x.contentHash===compositionSummary.contentHash);
  const counts=composition.snapshot();check(counts.total===26&&counts.positive===24&&counts.denied===2&&counts.unresolved===0&&counts.negativeRpc===1,'p03_composition_effect_counts');
 }
 const after=fingerprint();check(expectedFinalFinancial===after,'p09_browser_financial_fingerprint_changed');ctx.write('browser-financial-after.json',{fingerprint:after},true);
 automatic=posts-4;check(automatic===0,'p09_browser_automatic_ticket_post');
 pass('browser-real-consumer-checked',{domPages:2,ticketVersions:composition?4:3,automaticPosts:automatic,financialFingerprintSha256:digest(after),productServiceRight:'NOT_CONNECTED',unknownIntentAfterDestroy:'SEPARATE_DURABILITY_CRITERIA'});
 return {...(composition?{compositionSummary,compositionFresh,compositionBasis,compositionIsolation,compositionCounts:composition.snapshot(),unknownScope:'P03-ticket-only',p09UnknownSave:'NOT_COVERED_MISSING_JOURNAL'}:{}),pageClosed:true,contextClosed:true,freshLoginVerified:true,reloadGetOnly:true,automaticTicketPosts:automatic,privateStorageHits:0,privateUrlHits:0,cacheAuditComplete:true};
}
export async function composeExistingMemberCase(ctx,state){
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-context-binding',edge:'before'}));
 const composition=bindCompositionContext(ctx);
 console.log('P03_ASSEMBLED_STAGE '+JSON.stringify({stage:'composition-context-binding',edge:'after'}));
 return browserCase(state,composition.ctx,composition);
}
