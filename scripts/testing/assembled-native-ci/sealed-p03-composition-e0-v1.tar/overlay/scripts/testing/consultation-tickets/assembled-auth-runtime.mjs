// P03 test-only derivative. Product imports none of this module.
// Pinned source/limited profile adaptation recorded in native-infrastructure-lineage.json.
// Shared lifecycle extracted from accepted PF10@80582f1. Existing CI only.
// Exactly two compiled profiles; no external target, SQL path or route configuration.
import {execFileSync,spawn} from 'node:child_process';
import {randomBytes,randomUUID,createHmac,createHash} from 'node:crypto';
import {mkdirSync,mkdtempSync,readFileSync,writeFileSync,openSync,writeSync,fsyncSync,closeSync,realpathSync,symlinkSync,copyFileSync} from 'node:fs';
import {resolve,dirname,posix} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {browserRequestAllowed} from './assembled-auth-gateway.mjs';
import {app as compositionApp,compositionNativeChecks} from './composition-contract.mjs';
import {createOwnedTransportGate} from './composition-transport.mjs';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../../..'),label='p03.assembled-native-lab';
export const origin='http://localhost:32189';
// Three START-A identities; root approved the explicit official v14.17 artifact
// mapping below for this lab only after legacy mirror 401 / digest 404.
export const restArtifact=Object.freeze({legacy:'sha256:34f9a5ffb70a016155142dfeb103b89523384b3f8d1a3087250c758675bf9272',index:'sha256:c9dc201e555f5d8e37e7f39cdd4df0229774996e213bfd7de8d10ac609030f2c',manifest:'sha256:aa7e96af2d01219a09bc00c75de28171b1f9fda17ea455a931e4fb6d317089e0',config:'sha256:fc3d286fec899d5a5bebbb98eac771ced1ccaa44deac8ce2fc23fe5d262eb3d9'});
export const images=Object.freeze({db:'postgres@sha256:b0f9560a2de083e2cc7382e75f808c7381a32852a7ec49117deedb300e552b24',auth:'supabase/gotrue@sha256:1736a63078f5922b198c4cbe50f80ab9a2d3b54fe8b7b6cfb2e9dc5dbbc12c6b',rest:'postgrest/postgrest@'+restArtifact.index,node:'node@sha256:e4bf2a82ad0a4037d28035ae71529873c069b13eb0455466ae0bc13363826e34'});
const check=(value,code)=>{if(!value)throw Error(code);},hash=value=>createHash('sha256').update(value).digest('hex');
export function verifyEnvironment(env=process.env,platform=process.platform){check(platform==='linux'&&env.CI==='true'&&env.GITHUB_ACTIONS==='true','pf10_native_requires_existing_linux_ci');check(env.RUNNER_TEMP&&posix.isAbsolute(env.RUNNER_TEMP)&&!env.RUNNER_TEMP.includes('\\'),'pf10_native_private_temp_required');}
export function verifyContainer(s,c,role){check(c.Config.Labels?.[label]===s.id&&c.State.Running&&c.Image===s.imageIds[role],'pf10_native_container_identity');check(!c.Mounts.some(m=>m.Type==='bind'),'pf10_native_host_bind');check(Object.keys(c.NetworkSettings.Networks).join()===s.network,'pf10_native_network_membership');check(!Object.keys(c.HostConfig.PortBindings??{}).length,'pf10_native_service_port');if(role==='db')check(c.Mounts.some(m=>m.Type==='tmpfs'&&m.Destination==='/var/lib/postgresql/data')||Object.hasOwn(c.HostConfig.Tmpfs??{},'/var/lib/postgresql/data'),'pf10_native_persistent_database');}
export function verifyIngress(s,c){check(c.Config.Labels?.[label]===s.id&&c.State.Running&&c.Image===s.imageIds.node&&!c.Mounts.some(m=>m.Type==='bind'),'pf10_native_ingress_identity');check(Object.keys(c.NetworkSettings.Networks).sort().join()===[s.network,s.edge].sort().join(),'pf10_native_ingress_network');const ports=c.HostConfig.PortBindings;check(Object.keys(ports).length===1&&ports['32190/tcp']?.length===1&&ports['32190/tcp'][0].HostIp==='127.0.0.1'&&ports['32190/tcp'][0].HostPort==='32190','pf10_native_ingress_exposure');}
export function verifyRestArtifact(details,index,version){check(details.Os==='linux'&&details.Architecture==='amd64'&&details.Id===restArtifact.config,'pf10_native_rest_platform_config');check(index.manifests?.some(m=>m.digest===restArtifact.manifest&&m.platform?.os==='linux'&&m.platform?.architecture==='amd64'),'pf10_native_rest_platform_manifest');check(/^PostgREST v?14\.17(?:[ .(-]|$)/.test(version),'pf10_native_rest_version');}
export function verifyDatabaseMountInfo(text){check(text.split('\n').some(line=>{const [mount,filesystem]=line.split(' - ');return mount?.split(' ')[4]==='/var/lib/postgresql/data'&&filesystem?.split(' ')[0]==='tmpfs';}),'pf10_native_database_kernel_not_tmpfs');}
export function allowedProfileURL(profile,value,browserMode=false,method='GET',acceptance='ticket'){const config=nativeAuthProfile(profile);check(['ticket','feedback-reader-v1','p03-composition-e0-v1'].includes(acceptance)&&typeof browserMode==='boolean'&&(!browserMode||profile==='consultation-ticket')&&(acceptance==='ticket'||browserMode),'p09_browser_profile_mode');const u=new URL(value);check(u.origin===origin&&u.username===''&&u.password===''&&(u.pathname.startsWith('/auth/v1/')||u.pathname.startsWith('/rest/v1/')||[config.identityPath,...config.routes].includes(u.pathname)||(browserMode&&browserRequestAllowed(value,method,acceptance))),'pf10_native_http_destination');return u.href;}

export const browserChecks=Object.freeze(['browser-preflight-before-provision','real-member-page-default-right-closed','real-201-discard-live-page-one-post','same-attempt-get-only-recovery','fresh-sdk-context-and-reload-get-only','real-advisor-response-and-member-followup','real-revoke-and-private-fallback-denial','desktop-mobile-and-private-storage-cache-url','unconfirmed-command-destroy-and-server-intent-get-only','unknown-preparation-destroy-no-command','owned-browser-cleanup']);
export const browserSourceSha='95dc9473b4f904cb3ab0800fc7206081fcae12abc094a088bd741a13f1747b72';
export const assembledCandidateSha='e0b930927563d7f9f6d79e848917c4ba0d77ed6f';
export const assembledDiagnosticChecks=Object.freeze(['immutable-source-default-closed','actual-sdk-same-jwt-own-versus-foreign-rls','expired-source-unverified-dom','active-source-unverified-dom','revoked-source-unverified-dom','advisor-other-client-zero-side-get','actual-sdk-identity-clear','actual-sdk-signout-clear','private-storage-url-and-owned-cleanup']);
export const assembledLegacySqlPin=Object.freeze({file:'sql/phase11_access_tiers.sql',bytes:5286,sha256:'5e17a04a76d70c91b6080145308711c7964371de3383ed33c2a7bdfd08d9c1dc'});
export const feedbackReaderSha='699ea1677c21c216be52869318cf0ac1c4525744';
export const feedbackSqlPins=Object.freeze([
 Object.freeze({file:'supabase/migrations/20261029142010_consultation_feedback_states.sql',bytes:12982,sha256:'32f928eac23f02c1412301932f7a58ebe1707b987d9b78d09ba67b1117913dda'}),
 Object.freeze({file:'supabase/migrations/20261029160723_consultation_feedback_rollout_guard.sql',bytes:18228,sha256:'5b3538d2a4526c91ac0af092b86a81b3e7bb140dab88ad20aef30abff2ff03e2'})
]);
export const feedbackReaderChecks=Object.freeze(['immutable-sql-and-default-closed','nonzero-published-version-and-valid-consent','actual-two-actor-partial-not-done','separate-app-stop-and-db-stop','fresh-password-sdk-get-and-original-dom-history','legacy-doing-done-and-stable-financials','revocation-and-member-history','owned-browser-cleanup-and-no-repeat']);
export function nativeBrowserMode(profile,options){
 if(options===undefined)return false;
 check(options&&typeof options==='object'&&!Array.isArray(options)&&Object.hasOwn(options,'browserMode')&&Object.keys(options).every(x=>['browserMode','acceptance'].includes(x))&&typeof options.browserMode==='boolean','p09_browser_options');
 check(!Object.hasOwn(options,'acceptance')||(['feedback-reader-v1','p03-composition-e0-v1'].includes(options.acceptance)&&options.browserMode===true),'p03_feedback_acceptance_options');
 check(!options.browserMode||profile==='consultation-ticket','p09_browser_profile_mode');return options.browserMode;
}
export function validateBrowserReceipt(value,expectedTempRoot=process.env.RUNNER_TEMP){
 check(value&&value.status==='PASS'&&value.driverVersion==='1.64.1'&&Array.isArray(value.checks)&&value.checks.length===browserChecks.length,'p09_browser_receipt_missing');
 check(browserChecks.every(name=>value.checks.filter(x=>x.name===name&&x.status==='PASS').length===1),'p09_browser_checks_incomplete');
 check(typeof expectedTempRoot==='string'&&posix.isAbsolute(expectedTempRoot)&&typeof value.ownerId==='string'&&/^[a-f0-9-]{36}$/.test(value.ownerId)&&typeof value.ownedTemp==='string'&&posix.dirname(value.ownedTemp)===posix.normalize(expectedTempRoot)&&/^p09b-[A-Za-z0-9]{6}$/.test(posix.basename(value.ownedTemp))&&value.executable===value.ownedTemp+'/chrome/chrome','p09_browser_receipt_owned_path');
 check(value.sourceExecutable==='/opt/google/chrome/chrome'&&value.sourceSha256===browserSourceSha&&value.chromeSha256===browserSourceSha&&/^Google Chrome [0-9.]+(?: .*)?$/.test(value.chromeVersion),'p09_browser_receipt_identity');
 check(value.closure?.sourceStable===true&&value.closure?.copyMatched===true&&value.closure?.runtimeReadonly===true&&/^[a-f0-9]{64}$/.test(value.closure?.sha256)&&Number.isSafeInteger(value.closure.entries)&&value.closure.entries>0&&value.closure.entries<=4096&&Number.isSafeInteger(value.closure.bytes)&&value.closure.bytes>0&&value.closure.bytes<=1024**3&&Number.isSafeInteger(value.closure.freeBeforeBytes)&&value.closure.freeBeforeBytes>=value.closure.bytes+4*1024**3,'p09_browser_receipt_closure');
 check(value.pageClosed===true&&value.contextClosed===true&&value.freshLoginVerified===true&&value.reloadGetOnly===true&&value.automaticTicketPosts===0&&value.privateStorageHits===0&&value.privateUrlHits===0&&value.cacheAuditComplete===true,'p09_browser_receipt_flow');
 check(value.cleanup?.processStopped===true&&value.cleanup?.contextsClosed===true&&value.cleanup?.ownedTempRemoved===true&&value.cleanup?.ownerId===value.ownerId,'p09_browser_cleanup_incomplete');
 return {status:'PASS',driverVersion:value.driverVersion,sourceExecutable:value.sourceExecutable,sourceSha256:value.sourceSha256,executable:value.executable,ownedTemp:value.ownedTemp,ownerId:value.ownerId,chromeVersion:value.chromeVersion,chromeSha256:value.chromeSha256,closure:{sha256:value.closure.sha256,entries:value.closure.entries,bytes:value.closure.bytes,freeBeforeBytes:value.closure.freeBeforeBytes,sourceStable:true,copyMatched:true,runtimeReadonly:true},checks:browserChecks.map(name=>({name,status:'PASS'})),pageClosed:true,contextClosed:true,freshLoginVerified:true,reloadGetOnly:true,automaticTicketPosts:0,privateStorageHits:0,privateUrlHits:0,cacheAuditComplete:true,cleanup:{processStopped:true,contextsClosed:true,ownedTempRemoved:true,ownerId:value.ownerId}};
}

export function validateFeedbackReaderReceipt(value,expectedTempRoot=process.env.RUNNER_TEMP){
 check(value&&value.status==='PASS'&&value.readerSha===feedbackReaderSha&&value.driverVersion==='1.64.1'&&Array.isArray(value.checks)&&value.checks.length===feedbackReaderChecks.length,'p03_feedback_receipt_shape');
 check(feedbackReaderChecks.every(name=>value.checks.filter(x=>x.name===name&&x.status==='PASS').length===1),'p03_feedback_receipt_checks');
 check(typeof expectedTempRoot==='string'&&posix.isAbsolute(expectedTempRoot)&&typeof value.ownerId==='string'&&/^[a-f0-9-]{36}$/.test(value.ownerId)&&typeof value.ownedTemp==='string'&&posix.dirname(value.ownedTemp)===posix.normalize(expectedTempRoot)&&/^p09b-[A-Za-z0-9]{6}$/.test(posix.basename(value.ownedTemp))&&value.executable===value.ownedTemp+'/chrome/chrome','p03_feedback_receipt_owned_path');
 check(value.sourceExecutable==='/opt/google/chrome/chrome'&&value.sourceSha256===browserSourceSha&&value.chromeSha256===browserSourceSha&&/^Google Chrome [0-9.]+(?: .*)?$/.test(value.chromeVersion),'p03_feedback_receipt_chrome');
 check(value.closure?.sourceStable===true&&value.closure?.copyMatched===true&&value.closure?.runtimeReadonly===true&&/^[a-f0-9]{64}$/.test(value.closure?.sha256)&&Number.isSafeInteger(value.closure.entries)&&value.closure.entries>0&&value.closure.entries<=4096&&Number.isSafeInteger(value.closure.bytes)&&value.closure.bytes>0&&value.closure.bytes<=1024**3&&Number.isSafeInteger(value.closure.freeBeforeBytes)&&value.closure.freeBeforeBytes>=value.closure.bytes+4*1024**3,'p03_feedback_receipt_closure');
 check(value.freshAuthActors===2&&value.originalRowsStable===true&&value.domHistoryVerified===true&&value.appStopVerified===true&&value.dbStopVerified===true&&value.legacyStatesVerified===true&&value.financialFingerprintUnchanged===true&&value.revocationVerified===true&&value.repeatedPosts===0&&value.domAutomaticPosts===0&&value.privateStorageHits===0&&value.privateUrlHits===0,'p03_feedback_receipt_flow');
 check(value.cleanup?.processStopped===true&&value.cleanup?.contextsClosed===true&&value.cleanup?.ownedTempRemoved===true&&value.cleanup?.ownerId===value.ownerId,'p03_feedback_receipt_cleanup');
 return {status:'PASS',readerSha:feedbackReaderSha,driverVersion:'1.64.1',sourceExecutable:value.sourceExecutable,sourceSha256:value.sourceSha256,executable:value.executable,ownedTemp:value.ownedTemp,ownerId:value.ownerId,chromeVersion:value.chromeVersion,chromeSha256:value.chromeSha256,closure:{sha256:value.closure.sha256,entries:value.closure.entries,bytes:value.closure.bytes,freeBeforeBytes:value.closure.freeBeforeBytes,sourceStable:true,copyMatched:true,runtimeReadonly:true},checks:feedbackReaderChecks.map(name=>({name,status:'PASS'})),freshAuthActors:2,originalRowsStable:true,domHistoryVerified:true,appStopVerified:true,dbStopVerified:true,legacyStatesVerified:true,financialFingerprintUnchanged:true,revocationVerified:true,repeatedPosts:0,domAutomaticPosts:0,privateStorageHits:0,privateUrlHits:0,cleanup:{processStopped:true,contextsClosed:true,ownedTempRemoved:true,ownerId:value.ownerId,processesObserved:value.cleanup.processesObserved}};
}
export function validateAssembledDiagnosticReceipt(value,expectedTempRoot=process.env.RUNNER_TEMP){
 check(value&&value.status==='PASS'&&value.readerSha===assembledCandidateSha&&value.driverVersion==='1.64.1'&&Array.isArray(value.checks)&&value.checks.length===assembledDiagnosticChecks.length,'p03_legacy_receipt_shape');
 check(assembledDiagnosticChecks.every(name=>value.checks.filter(x=>x.name===name&&x.status==='PASS').length===1),'p03_legacy_receipt_checks');
 check(typeof expectedTempRoot==='string'&&posix.isAbsolute(expectedTempRoot)&&typeof value.ownerId==='string'&&/^[a-f0-9-]{36}$/.test(value.ownerId)&&typeof value.ownedTemp==='string'&&posix.dirname(value.ownedTemp)===posix.normalize(expectedTempRoot)&&/^p09b-[A-Za-z0-9]{6}$/.test(posix.basename(value.ownedTemp))&&value.executable===value.ownedTemp+'/chrome/chrome','p03_legacy_receipt_owned_path');
 check(value.sourceExecutable==='/opt/google/chrome/chrome'&&value.sourceSha256===browserSourceSha&&value.chromeSha256===browserSourceSha&&/^Google Chrome [0-9.]+(?: .*)?$/.test(value.chromeVersion),'p03_legacy_receipt_chrome');
 check(value.closure?.sourceStable===true&&value.closure?.copyMatched===true&&value.closure?.runtimeReadonly===true&&/^[a-f0-9]{64}$/.test(value.closure?.sha256)&&Number.isSafeInteger(value.closure.entries)&&value.closure.entries>0&&value.closure.entries<=4096&&Number.isSafeInteger(value.closure.bytes)&&value.closure.bytes>0&&value.closure.bytes<=1024**3&&Number.isSafeInteger(value.closure.freeBeforeBytes)&&value.closure.freeBeforeBytes>=value.closure.bytes+4*1024**3,'p03_legacy_receipt_closure');
 for(const key of ['sameJwtVerified','ownForeignRlsVerified','expiredDomVerified','activeDomVerified','revokedDomVerified','advisorZeroSideGetVerified','identityCleared','signoutCleared','readOnlyGrantOnly','productWriteClosed'])check(value[key]===true,'p03_legacy_receipt_flow');
 check(value.domAutomaticPosts===0&&value.privateStorageHits===0&&value.privateUrlHits===0&&value.productServiceRight==='NOT_CONNECTED','p03_legacy_receipt_private_or_right');
 check(value.cleanup?.processStopped===true&&value.cleanup?.contextsClosed===true&&value.cleanup?.ownedTempRemoved===true&&value.cleanup?.ownerId===value.ownerId,'p03_legacy_receipt_cleanup');
 return {status:'PASS',readerSha:assembledCandidateSha,driverVersion:value.driverVersion,sourceExecutable:value.sourceExecutable,sourceSha256:value.sourceSha256,executable:value.executable,ownedTemp:value.ownedTemp,ownerId:value.ownerId,chromeVersion:value.chromeVersion,chromeSha256:value.chromeSha256,closure:{sourceStable:true,copyMatched:true,runtimeReadonly:true,sha256:value.closure.sha256,entries:value.closure.entries,bytes:value.closure.bytes,freeBeforeBytes:value.closure.freeBeforeBytes},checks:assembledDiagnosticChecks.map(name=>({name,status:'PASS'})),sameJwtVerified:true,ownForeignRlsVerified:true,expiredDomVerified:true,activeDomVerified:true,revokedDomVerified:true,advisorZeroSideGetVerified:true,identityCleared:true,signoutCleared:true,readOnlyGrantOnly:true,productWriteClosed:true,domAutomaticPosts:0,privateStorageHits:0,privateUrlHits:0,productServiceRight:'NOT_CONNECTED',targetInstall:'NOT_APPLIED',arashAcceptance:'UNOBSERVED',cleanup:{processStopped:true,contextsClosed:true,ownedTempRemoved:true,ownerId:value.ownerId}};
}
const profiles={"consultation-ticket": {"sourceShaEnv": "P01_P03_ASSEMBLED_NATIVE_SOURCE_SHA", "logPrefix": "P03_TICKET", "identityPath": "/__p03_ticket_native_identity", "phases": 27, "browserPhases": 4, "actors": {"a": "user", "b": "user", "owner": "admin", "admin": "admin"}, "bootstrap": ["sql/test/supabase_bootstrap.sql", "sql/test/profile_explicit_grants.sql", "sql/test/portfolio_precondition.sql", "sql/phase32_member_holdings.sql", "supabase/migrations/20261003094257_recovery_personal_balance_sheet_core.sql", "supabase/migrations/20261019215549_personal_cash_flow_versions.sql", "sql/member_goals_versions_20261023.sql", "sql/phase34_research_workbook_versions.sql", "scripts/testing/consultation-tickets/bootstrap-fixture.sql", "sql/consultation_workflow.sql", "sql/consultation_roster.sql", "sql/consultation_replies.sql", "sql/consultation_ticket_requests.sql", "sql/consultation_ticket_prepared_intents.sql", "supabase/migrations/20261029142010_consultation_feedback_states.sql", "supabase/migrations/20261029160723_consultation_feedback_rollout_guard.sql", "sql/phase11_access_tiers.sql", "supabase/migrations/20261003094327_member_investment_scope_reviews.sql"], "sql": ["sql/test/supabase_bootstrap.sql", "sql/test/profile_explicit_grants.sql", "sql/test/portfolio_precondition.sql", "sql/phase32_member_holdings.sql", "supabase/migrations/20261003094257_recovery_personal_balance_sheet_core.sql", "supabase/migrations/20261019215549_personal_cash_flow_versions.sql", "sql/member_goals_versions_20261023.sql", "sql/phase34_research_workbook_versions.sql", "scripts/testing/assembled-member-admins/bootstrap-fixture.sql", "sql/consultation_workflow.sql", "sql/consultation_roster.sql", "sql/consultation_replies.sql", "sql/consultation_ticket_requests.sql", "sql/consultation_ticket_prepared_intents.sql", "scripts/testing/assembled-member-admins/owned-fixture.sql", "scripts/testing/consultation-tickets/owned-fixture.sql", "scripts/testing/consultation-tickets/bootstrap-fixture.sql", "supabase/migrations/20261029142010_consultation_feedback_states.sql", "supabase/migrations/20261029160723_consultation_feedback_rollout_guard.sql", "sql/phase11_access_tiers.sql", "supabase/migrations/20261003094327_member_investment_scope_reviews.sql"], "routes": ["/api/consultation", "/api/consultation/roster", "/api/consultation/replies", "/api/consultation/tickets", "/api/consultation/ticket-attempts", "/api/portfolio/holdings", "/api/portfolio/debts", "/api/personal-finance/cash-flow", "/api/personal-finance/goals", "/api/portfolio/holdings/scope"], "warmup": [["/api/consultation", 401], ["/api/consultation/ticket-attempts?mode=list&relationshipId=00000000-0000-4000-8000-000000000001", 401], ["/api/consultation/tickets?mode=inbox&relationshipId=00000000-0000-4000-8000-000000000001", 401], ["/api/portfolio/holdings", 401]]}};
for(const config of Object.values(profiles)){for(const key of ['actors','bootstrap','sql','routes','warmup']){if(key==='warmup')config[key].forEach(Object.freeze);Object.freeze(config[key]);}Object.freeze(config);}Object.freeze(profiles);
export function nativeAuthProfile(profile){check(typeof profile==='string'&&Object.hasOwn(profiles,profile),'pf10_native_unknown_profile');return profiles[profile];}

const quote=x=>x===null?'NULL':typeof x==='number'?String(x):"'"+String(x).replaceAll("'","''")+"'";
function bootstrapToken(secret,role){check(['anon','service_role'].includes(role),'pf10_native_member_token_must_come_from_auth');const body=Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url')+'.'+Buffer.from(JSON.stringify({role,iss:'supabase',iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+3600})).toString('base64url');return body+'.'+createHmac('sha256',secret).update(body).digest('base64url');}
export async function runNativeAuthProfile(profile,exercise,options){
 const browserMode=nativeBrowserMode(profile,options),acceptance=options?.acceptance??'ticket',feedbackMode=acceptance==='feedback-reader-v1',assembledMode=acceptance==='p03-composition-e0-v1';
 const base=nativeAuthProfile(profile),config=feedbackMode?{...base,logPrefix:'P03_FEEDBACK',browserPhases:feedbackReaderChecks.length+2}:assembledMode?{...base,logPrefix:'P03_ASSEMBLED',browserPhases:compositionNativeChecks.length}:base;check(typeof exercise==='function','pf10_native_scenario_required');
 verifyEnvironment();const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:120000}).trim();
 const checkoutSha=git(['rev-parse','HEAD']),sha=process.env[config.sourceShaEnv]??checkoutSha;check(/^[a-f0-9]{40}$/.test(sha),'pf10_native_source_sha');check(git(['status','--porcelain','--untracked-files=no'])==='','pf10_native_dirty_source');
 try{git(['cat-file','-e',sha+'^{commit}']);}catch{check(git(['remote','get-url','origin']).replace(/\.git$/,'')==='https://github.com/safariarash7777-source/portfolio-platform','pf10_native_source_remote');git(['fetch','--no-tags','--depth=1','origin',sha]);}
 check(git(['rev-parse',checkoutSha+'^{tree}'])===git(['rev-parse',sha+'^{tree}']),'pf10_native_head_merge_tree_mismatch');
 if(assembledMode){for(const path of ['app','lib','components','public','middleware.ts','next.config.js','package.json','package-lock.json','sql','supabase'])check(git(['rev-parse',sha+':'+path])===git(['rev-parse',assembledCandidateSha+':'+path]),'p03_legacy_reader_source_changed');}
 if(feedbackMode){for(const path of ['app','lib','components','public','middleware.ts','next.config.js','package.json','package-lock.json'])check(git(['rev-parse',sha+':'+path])===git(['rev-parse',feedbackReaderSha+':'+path]),'p03_feedback_reader_source_changed');}
 check(sha===assembledCandidateSha,'assembled_exact_candidate_required');
 const privateDir=mkdtempSync(resolve(process.env.RUNNER_TEMP,profile+'-native-'));check(realpathSync(privateDir)===privateDir,'pf10_native_private_path_redirect');
 const id=profile+'-'+randomUUID(),s={id,sha,network:id+'-internal',edge:id+'-edge',resources:[],imageIds:{},migrations:[],local:privateDir,password:randomBytes(24).toString('hex'),secret:randomBytes(32).toString('hex')};
 for(const role of ['db','auth','rest','ingress'])s[role]=id+'-'+role;
 let host;const results=[];let postCount=0,ticketPosts=0,preparationPosts=0;let compositionObserved=null;const authFacts={createAttempts:0,passwordAttempts:0,logoutAttempts:0,negativeRpcAttempts:0,createdIds:[],verifiedPasswordActors:[]};
 const countWrite=path=>{if(path==='/api/consultation/tickets')ticketPosts++;if(path==='/api/consultation/ticket-attempts')preparationPosts++;};
 const writeCounts=()=>({ticketPosts,preparationPosts});
 const stopHost=async()=>{if(host&&host.exitCode===null){const child=host;child.kill('SIGTERM');await new Promise(r=>{const timer=setTimeout(()=>{child.kill('SIGKILL');r();},8000);child.once('exit',()=>{clearTimeout(timer);r();});});}};
 const write=(name,value,exclusive=false)=>{check(/^[a-z0-9.-]+$/.test(name),'pf10_native_private_filename');const fd=openSync(resolve(privateDir,name),exclusive?'wx':'w',0o600);try{writeSync(fd,JSON.stringify(value,null,2)+'\n');fsyncSync(fd);}finally{closeSync(fd);}};
 const save=()=>write('state.json',s);
 const docker=(args,input)=>{try{return execFileSync('docker',args,{input,encoding:'utf8',stdio:['pipe','pipe','pipe'],timeout:120000,maxBuffer:8*1024*1024}).trim();}catch{throw Error('pf10_native_docker_operation_failed');}};
 const inspect=name=>JSON.parse(docker(['inspect',name]))[0];
 const attestDB=()=>{const n=JSON.parse(docker(['network','inspect',s.network]))[0];check(n.Internal&&n.Labels?.[label]===id,'pf10_native_internal_network');verifyContainer(s,inspect(s.db),'db');verifyDatabaseMountInfo(docker(['exec',s.db,'cat','/proc/self/mountinfo']));};
 const sql=query=>{attestDB();return docker(['exec','-i',s.db,'psql','-U','postgres','-XqAt','-v','ON_ERROR_STOP=1','-v','VERBOSITY=verbose'],query);};
 const envFile=(role,values)=>{const path=resolve(privateDir,role+'.env');writeFileSync(path,Object.entries(values).map(([k,v])=>`${k}=${v}`).join('\n'),{mode:0o600});return path;};
 const start=(role,values,extra=[])=>{docker(['run','-d','--pull','never','--name',s[role],'--label',`${label}=${id}`,'--network',s.network,'--network-alias',role,'--log-driver','none','--env-file',envFile(role,values),...extra,s.imageIds[role]]);s.resources.push({type:'container',name:s[role]});save();};
 const wait=async(fn,code,attempts=90)=>{let lastCode='not_ready';for(let i=0;i<attempts;i++){try{if(await fn())return;}catch(error){lastCode=/^pf10_native_[a-z0-9_]+$/.test(error.message)?error.message:'read_failed';}await new Promise(r=>setTimeout(r,1000));}throw Error(code+'_'+lastCode);};
 const directPostCounts=new Map(),directPostCaps=Object.freeze({'/api/portfolio/holdings':2,'/api/personal-finance/cash-flow':1,'/api/consultation':9,'/api/consultation/tickets':1,'/api/consultation/ticket-attempts':2,'/api/consultation/replies':2});
 s.transportRejected=0;
 const transportGate=createOwnedTransportGate({origin,
  allowDestination:(url,method)=>allowedProfileURL(profile,url,browserMode,method,acceptance),
  forward:(url,options)=>fetch(url,{...options,redirect:'error',signal:options.signal??AbortSignal.timeout(15000)}),
  journalReject:row=>{s.transportRejected=row.ordinal;write('transport-rejected-'+String(row.ordinal).padStart(3,'0')+'.json',row,true);save();}});
 const transport=transportGate.read;
 const post=async(path,body,headers={})=>{
  transportGate.assertClean();
  if(path==='/auth/v1/admin/users'){if(++authFacts.createAttempts>4)return transportGate.reject('AUTH_CREATE_CAP');}
  else if(path==='/auth/v1/token?grant_type=password'){if(++authFacts.passwordAttempts>9)return transportGate.reject('AUTH_PASSWORD_CAP');}
  else if(path==='/auth/v1/logout'){if(++authFacts.logoutAttempts>4)return transportGate.reject('AUTH_LOGOUT_CAP');}
  else if(path==='/rest/v1/rpc/lookup_consultation_ticket_attempt'){if(++authFacts.negativeRpcAttempts>1)return transportGate.reject('NEGATIVE_RPC_CAP');}
  else if(Object.hasOwn(directPostCaps,path)){const count=directPostCounts.get(path)??0;if(count>=directPostCaps[path])return transportGate.reject('DIRECT_PRODUCT_CAP');directPostCounts.set(path,count+1);}
  else return transportGate.reject('DIRECT_ROUTE_FORBIDDEN');
  try{write('intent-'+String(++postCount).padStart(3,'0')+'.json',{path,body,sha},true);countWrite(path);}
  catch{return transportGate.reject('INTENT_JOURNAL_FAILED');}
  try{const response=await transportGate.write(origin+path,{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)});write('transport-result-'+String(postCount).padStart(3,'0')+'.json',{ordinal:postCount,path,status:response.status,sha},true);return response;}
  catch{return transportGate.reject('WRITE_RESULT_UNKNOWN');}
 };
 const postExact=async()=>transportGate.reject('RAW_POST_DISABLED');
 const pass=(name,evidence={})=>{const item={name,status:'PASS',...evidence};results.push(item);write('results.json',{sha,results});console.log(config.logPrefix+'_NATIVE_CHECK '+JSON.stringify(item));};
 let cleanup='NOT_STARTED',browserReceipt;
 try{
  // Immutable identities only: root-approved official REST mapping is explicit.
  // No paid service, tool installation, tag fallback or real credentials.
  for(const [role,image] of Object.entries(images)){console.log(config.logPrefix+'_NATIVE_SETUP '+JSON.stringify({phase:'pinned-image',role,image}));
   try{execFileSync('docker',['pull','--platform','linux/amd64',image],{encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:120000});}
   catch(error){const detail=String(error.stderr??'');const code=/manifest unknown|not found/i.test(detail)?'manifest_missing':/denied|unauthorized|authentication required/i.test(detail)?'registry_denied':/timeout|TLS|x509|dial tcp/i.test(detail)?'registry_transport':'pull_failed';throw Error(`pf10_native_${role}_${code}`);}
   const details=JSON.parse(docker(['image','inspect',image]))[0];check(details.RepoDigests?.some(x=>x.endsWith('@'+image.split('@')[1])),'pf10_native_image_digest');s.imageIds[role]=details.Id;
   if(role==='rest'){const index=JSON.parse(docker(['manifest','inspect',image]));const version=docker(['run','--rm','--pull','never','--name',id+'-rest-version','--label',`${label}=${id}`,'--platform','linux/amd64','--network','none','--read-only','--cap-drop','ALL',details.Id,'/bin/postgrest','--version']);verifyRestArtifact(details,index,version);s.restArtifact={...restArtifact,version,primaryArtifactMatch:'NOT_CLAIMED'};console.log(config.logPrefix+'_NATIVE_SETUP '+JSON.stringify({phase:'rest-artifact-readback',...s.restArtifact}));}
  }
  save();docker(['network','create','--internal','--label',`${label}=${id}`,s.network]);s.resources.push({type:'network',name:s.network});save();
  start('db',{POSTGRES_PASSWORD:s.password},['--tmpfs','/var/lib/postgresql/data']);const dbMeta=inspect(s.db);console.log(config.logPrefix+'_NATIVE_SETUP '+JSON.stringify({phase:'db-mount-readback',mounts:dbMeta.Mounts.map(m=>({type:m.Type,destination:m.Destination})),tmpfs:Object.keys(dbMeta.HostConfig.Tmpfs??{}),ownerMatches:dbMeta.Config.Labels?.[label]===id,imageMatches:dbMeta.Image===s.imageIds.db,networks:Object.keys(dbMeta.NetworkSettings.Networks)}));await wait(()=>sql('SELECT 1')==='1','pf10_native_database_readiness');
  sql(`CREATE SCHEMA auth;CREATE SCHEMA e2e_identity;CREATE TABLE e2e_identity.environment(run_id text NOT NULL);INSERT INTO e2e_identity.environment VALUES(${quote(id)});`);
  const dbUrl=user=>{const u=new URL('postgres://db:5432/postgres');u.username=user;u.password=s.password;return u.href;};
  start('auth',{GOTRUE_API_HOST:'0.0.0.0',GOTRUE_API_PORT:9999,API_EXTERNAL_URL:origin+'/auth/v1',GOTRUE_DB_DRIVER:'postgres',GOTRUE_DB_DATABASE_URL:dbUrl('postgres')+'?search_path=auth',GOTRUE_SITE_URL:origin,GOTRUE_JWT_SECRET:s.secret,GOTRUE_JWT_EXP:3600,GOTRUE_JWT_AUD:'authenticated',GOTRUE_JWT_DEFAULT_GROUP_NAME:'authenticated',GOTRUE_JWT_ADMIN_ROLES:'service_role',GOTRUE_EXTERNAL_EMAIL_ENABLED:true,GOTRUE_MAILER_AUTOCONFIRM:true,GOTRUE_DISABLE_SIGNUP:true,GOTRUE_EXTERNAL_PHONE_ENABLED:false,GOTRUE_SMTP_HOST:'127.0.0.1',GOTRUE_SMTP_PORT:1,LOG_LEVEL:'error'});
  await wait(()=>sql("SELECT count(*) FROM information_schema.columns WHERE table_schema='auth' AND table_name='users' AND column_name='email'")==='1','pf10_native_auth_schema');
  const apply=file=>{const pin=assembledMode&&file===assembledLegacySqlPin.file?assembledLegacySqlPin:feedbackMode?feedbackSqlPins.find(x=>x.file===file):null;check(config.sql.includes(file)||pin,'pf10_native_migration_not_in_profile');const raw=readFileSync(resolve(root,file));if(pin)check(raw.length===pin.bytes&&hash(raw)===pin.sha256,'p03_feedback_immutable_sql_changed');const contents=raw.toString('utf8');sql(contents);s.migrations.push({file,sha256:hash(contents)});save();};
  for(const file of config.bootstrap)apply(file);
  if(feedbackMode)for(const pin of feedbackSqlPins)apply(pin.file);
  // New profile bootstrap already includes the exact legacy SQL once.
  // Transport login only. No extra table/private-function grant is added.
  sql(`CREATE ROLE authenticator LOGIN NOINHERIT PASSWORD ${quote(s.password)};GRANT anon,authenticated,service_role TO authenticator;`);
  start('rest',{PGRST_DB_URI:dbUrl('authenticator'),PGRST_DB_SCHEMAS:'public',PGRST_DB_ANON_ROLE:'anon',PGRST_JWT_SECRET:s.secret,PGRST_LOG_LEVEL:'crit'});
  docker(['network','create','--label',`${label}=${id}`,s.edge]);s.resources.push({type:'network',name:s.edge});save();
  const proxy="const h=require('http');h.createServer((q,s)=>{const auth=q.url.startsWith('/auth/v1/'),rest=q.url.startsWith('/rest/v1/');if(!auth&&!rest){s.writeHead(404);s.end();return}const r=h.request({hostname:auth?'auth':'rest',port:auth?9999:3000,path:q.url.slice(8),method:q.method,headers:q.headers},p=>{s.writeHead(p.statusCode,p.headers);p.pipe(s)});r.on('error',()=>{s.writeHead(502);s.end()});q.pipe(r)}).listen(32190,'0.0.0.0')";
  docker(['run','-d','--pull','never','--name',s.ingress,'--label',`${label}=${id}`,'--network',s.edge,'--log-driver','none','-p','127.0.0.1:32190:32190',s.imageIds.node,'node','-e',proxy]);s.resources.push({type:'container',name:s.ingress});save();docker(['network','connect',s.network,s.ingress]);
  const context=resolve(privateDir,'source');mkdirSync(context);const archive=resolve(privateDir,'source.tar');
  execFileSync('git',['-c','core.autocrlf=false','-c','core.eol=lf','archive','--format=tar','--output',archive,sha,'app','components','lib','public','middleware.ts','next.config.js','tsconfig.json','tailwind.config.js','postcss.config.js','package.json','package-lock.json'],{cwd:root,stdio:'pipe'});
  execFileSync('tar',['-xf',archive,'-C',context],{stdio:'pipe'});check(hash(readFileSync(resolve(context,'package-lock.json')))===hash(readFileSync(resolve(root,'package-lock.json'))),'pf10_native_dependency_lock');symlinkSync(resolve(root,'node_modules'),resolve(context,'node_modules'),'dir');copyFileSync(resolve(here,'assembled-auth-gateway.mjs'),resolve(context,'gateway.mjs'));
  for(const file of ['assembled-native-profile.mjs','assembled-native-source.json'])copyFileSync(resolve(here,file),resolve(context,file));
  const anon=bootstrapToken(s.secret,'anon'),service=bootstrapToken(s.secret,'service_role');s.anon=anon;s.service=service;save();
  const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>['PATH','TMPDIR','LANG'].includes(key)));
  Object.assign(env,{NEXT_PUBLIC_SUPABASE_URL:origin,NEXT_PUBLIC_SUPABASE_ANON_KEY:anon,NEXT_PUBLIC_APP_URL:origin,NEXT_TELEMETRY_DISABLED:'1',NATIVE_AUTH_PROFILE:profile,NATIVE_AUTH_ORIGIN:origin,NATIVE_AUTH_SHA:sha,NATIVE_AUTH_RUN:id});
  if(browserMode)env.NATIVE_AUTH_BROWSER_MODE='true';
  let released=false;
  const startHost=()=>{const log=openSync(resolve(privateDir,'app.log'),'a',0o600),serverEnv={...env};if(released)serverEnv.CONSULTATION_P03_WRITES_RELEASE='reader-compatible-v1';if(feedbackMode||assembledMode)serverEnv.NATIVE_AUTH_ACCEPTANCE_MODE=acceptance;host=spawn(process.execPath,['gateway.mjs'],{cwd:context,env:serverEnv,stdio:['ignore',log,log]});closeSync(log);host.on('error',()=>{});};
  startHost();
  const identity=async()=>{const r=await transport(origin+config.identityPath);const body=await r.json();check(body.runId===id&&body.sha===sha&&body.profile===profile,'pf10_native_host_identity');return true;};
  await wait(identity,'pf10_native_app_readiness',120);
  // Test-runner control of this owned process only; no HTTP/client/DB-fixture
  // switch and no propagation of inherited deployment flags or real service rights.
  const setWriteRelease=async enabled=>{check(typeof enabled==='boolean','p03_release_boolean');if(enabled===released)return;await stopHost();released=enabled;startHost();await wait(identity,'pf10_native_app_readiness',120);};
  const attest=async()=>{for(const role of ['db','auth','rest'])verifyContainer(s,inspect(s[role]),role);verifyIngress(s,inspect(s.ingress));check(sql('SELECT run_id FROM e2e_identity.environment')===id,'pf10_native_database_marker');await identity();return {sha,runId:id,images:Object.fromEntries(Object.entries(images)),restArtifact:s.restArtifact,database:'owned tmpfs',serviceNetwork:'internal/no host binds/no published service ports',ingress:'127.0.0.1:32190 only',app:'Linux runner loopback / sanitized env / exact Git archive',appDefaultRoutes:null,appNoEgressClaim:false};};
  pass('isolation-attested',await attest());
  await wait(async()=>{const r=await transport(origin+'/auth/v1/health');return r.ok;},'pf10_native_auth_ready');
  await wait(async()=>{const r=await transport(origin+'/rest/v1/',{headers:{apikey:anon}});return r.ok;},'pf10_native_rest_ready');
  for(const [path,status] of config.warmup){const r=await transport(origin+path,{signal:AbortSignal.timeout(120000)});check(r.status===status,'pf10_native_guest_warmup');}
  const {createServerClient}=createRequire(resolve(root,'package.json'))('@supabase/ssr');const users={};
  const newSession=async actor=>{const u=users[actor];const r=await post('/auth/v1/token?grant_type=password',{email:u.email,password:u.password},{apikey:anon});check(r.status===200,'pf10_native_auth_login');const session=await r.json();check(session.user?.id===u.id&&session.user?.app_metadata?.acceptance_run===id,'pf10_native_auth_issued_identity');check(typeof session.access_token==='string'&&typeof session.refresh_token==='string','pf10_native_auth_issued_tokens');const jar=new Map();
   const client=createServerClient(origin,anon,{auth:{autoRefreshToken:false,detectSessionInUrl:false},cookies:{getAll:()=>[...jar].map(([name,value])=>({name,value})),setAll:items=>items.forEach(x=>jar.set(x.name,x.value))},global:{fetch:(url,init)=>transportGate.sdkRead(u.id,session.access_token,anon,url,init)}});
   const set=await client.auth.setSession({access_token:session.access_token,refresh_token:session.refresh_token}),verified=await client.auth.getUser();check(!set.error&&!verified.error&&verified.data.user?.id===u.id&&jar.size>0,'pf10_native_sdk_verified_identity');authFacts.verifiedPasswordActors.push(u.id);return {cookie:[...jar].map(([k,v])=>`${k}=${encodeURIComponent(v)}`).join('; '),token:session.access_token};
  };
  for(const actor of Object.keys(config.actors)){const u={email:`${actor}-${id}@example.invalid`,password:randomBytes(24).toString('hex')};const r=await post('/auth/v1/admin/users',{...u,email_confirm:true,app_metadata:{acceptance_run:id}},{Authorization:'Bearer '+service,apikey:anon});check(r.status===200||r.status===201,'pf10_native_auth_create');const value=await r.json();check(/^[a-f0-9-]{36}$/.test(value.id),'pf10_native_auth_new_uuid');u.id=value.id;authFacts.createdIds.push(value.id);users[actor]=u;sql(`INSERT INTO public.profiles(id,role) VALUES(${quote(u.id)},${quote(config.actors[actor])});`);u.session=await newSession(actor);}
  write('users.json',users,true);pass('four-fresh-auth-users-and-sdk-getuser',{members:Object.values(config.actors).filter(x=>x==='user').length,admin:Object.values(config.actors).filter(x=>x==='admin').length,memberTokenSource:'GoTrue password grant; no hand-signed member sub'});
  const api=async(actor,path,body)=>{const headers={Cookie:users[actor].session.cookie,Origin:origin};const r=body===undefined?await transport(origin+path,{headers}):await post(path,body,headers);return {status:r.status,value:await r.json(),cache:r.headers.get('cache-control')};};
  // Inserted into the SAME owned parent lifecycle after real API definitions.
  // These observations come from successful actual runtime calls and readback,
  // never from an exercise-provided ctx literal.
  const attestComposition=async()=>{
   transportGate.assertClean();check(transportGate.snapshot().authorizedPostRequests===8,'p03_composition_actual_initial_auth_transport');
   const isolation=await attest();attestDB();
   const currentSha=git(['rev-parse','HEAD']),currentTree=git(['rev-parse','HEAD^{tree}']);
   check(currentSha===sha&&currentSha===assembledCandidateSha&&currentTree===compositionApp.tree,'p03_composition_actual_source');
   const response=await transport(origin+config.identityPath),server=await response.json();
   check(response.status===200&&server.runId===id&&server.sha===sha&&server.profile===profile&&server.writeRelease===true&&released===true,'p03_composition_actual_server');
   const actualActors=JSON.parse(sql("SELECT coalesce(jsonb_agg(jsonb_build_object('id',a.id,'run',a.raw_app_meta_data->>'acceptance_run','role',p.role) ORDER BY a.id),'[]') FROM auth.users a JOIN public.profiles p ON p.id=a.id"));
   check(actualActors.length===4&&authFacts.createAttempts===4&&authFacts.passwordAttempts===4&&authFacts.verifiedPasswordActors.length===4,'p03_composition_actual_auth_counts');
   const expectedIds=Object.values(users).map(u=>u.id).sort();
   check(new Set(authFacts.createdIds).size===4&&JSON.stringify([...authFacts.createdIds].sort())===JSON.stringify(expectedIds)&&actualActors.every(a=>a.run===id&&expectedIds.includes(a.id)&&a.role===config.actors[Object.keys(users).find(k=>users[k].id===a.id)]),'p03_composition_actual_actor_rows');
   const permission=JSON.parse(sql('SELECT consultation_ticket_private.permission(NULL::uuid,NULL::uuid)::text'));
   check(permission.state==='not_connected','p03_composition_actual_default_right');
   const observation={schema:'p03-composition-binding.v1',appSha:currentSha,appTree:currentTree,
    allocationId:process.env.ASSEMBLED_NATIVE_ALLOCATION_ID,runId:id,profile,origin,
    tmpfsVerified:isolation.database==='owned tmpfs',authCreatedIds:[...authFacts.createdIds],initialPasswordLogins:authFacts.passwordAttempts,
    productServiceRight:permission.state==='not_connected'?'NOT_CONNECTED':null,serverWritesReleased:server.writeRelease===true,
    actors:actualActors,images:isolation.images,resources:s.resources.map(r=>({...r})),
    databaseMarker:sql('SELECT run_id FROM e2e_identity.environment'),local:privateDir,transportInitial:transportGate.snapshot()};
   check(/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(observation.allocationId)&&observation.databaseMarker===observation.runId&&observation.profile==='consultation-ticket','p03_composition_actual_allocation_run');
   write('composition-binding.json',observation,true);
   return Object.freeze({...observation,authCreatedIds:Object.freeze(observation.authCreatedIds)});
  };
  const observedAuth=()=>{transportGate.assertClean();return ({createAttempts:authFacts.createAttempts,passwordAttempts:authFacts.passwordAttempts,logoutAttempts:authFacts.logoutAttempts,negativeRpcAttempts:authFacts.negativeRpcAttempts,createdIds:[...authFacts.createdIds],verifiedPasswordActors:[...authFacts.verifiedPasswordActors]});};

  const observeCompositionDatabase=()=>{
   // sql() attests the real owned container/network/kernel tmpfs before use.
   const observed=JSON.parse(sql(`BEGIN READ ONLY;SELECT jsonb_build_object(
    'capturedAt',clock_timestamp(),
    'databaseMarker',(SELECT run_id FROM e2e_identity.environment),
    'authUsers',(SELECT count(*) FROM auth.users),
    'relationships',(SELECT coalesce(jsonb_agg(jsonb_build_object('id',r.id,'clientId',r.client_id,'advisorId',r.advisor_id,'revoked',EXISTS(SELECT FROM public.consultation_revocations v WHERE v.relationship_id=r.id)) ORDER BY r.id),'[]') FROM public.consultation_relationships r),
    'requests',(SELECT count(*) FROM consultation_ticket_private.requests),
    'requestLinks',(SELECT coalesce(jsonb_agg(jsonb_build_object('requestId',r.request_id,'relationshipId',r.relationship_id) ORDER BY r.request_id),'[]') FROM consultation_ticket_private.requests r),
    'recommendationLinks',(SELECT coalesce(jsonb_agg(jsonb_build_object('requestId',e.request_id,'version',e.version,'recommendation',e.command->'recommendation') ORDER BY e.request_id,e.version),'[]') FROM consultation_ticket_private.events e WHERE e.command->>'kind'='link_recommendation'),
    'ticketEvents',(SELECT count(*) FROM consultation_ticket_private.events),
    'preparedIntents',(SELECT count(*) FROM consultation_ticket_private.prepared_intents),
    'sessions',(SELECT coalesce(jsonb_agg(jsonb_build_object('id',s.id,'relationshipId',s.relationship_id,'version',s.version,'contentHash',s.content_hash,'basis',s.body->'basis') ORDER BY s.id),'[]') FROM public.consultation_sessions s),
    'summaryEvents',(SELECT count(*) FROM public.consultation_events),
    'publications',(SELECT count(*) FROM public.consultation_publications),
    'feedback',(SELECT count(*) FROM public.consultation_actions),
    'replyVersions',(SELECT count(*) FROM public.consultation_reply_versions),
    'holdingVersions',(SELECT count(*) FROM public.member_holding_versions),
    'holdingOwnership',(SELECT coalesce(jsonb_agg(jsonb_build_object('userId',h.user_id,'version',h.version,'clientToken',h.client_token) ORDER BY h.version),'[]') FROM public.member_holding_versions h),
    'cashFlowVersions',(SELECT count(*) FROM public.member_cash_flow_versions)
   );COMMIT;`));
   check(observed.databaseMarker===id&&observed.authUsers===4&&observed.relationships.length===1&&observed.relationships[0].clientId===users.a.id&&observed.relationships[0].advisorId===users.owner.id&&observed.relationships[0].revoked===true,'p03_composition_db_relationship');
   for(const [key,value] of Object.entries({requests:2,ticketEvents:5,preparedIntents:6,summaryEvents:3,publications:1,feedback:3,replyVersions:1,holdingVersions:2,cashFlowVersions:1}))check(observed[key]===value,'p03_composition_db_effects');
   check(observed.sessions.length===1&&observed.sessions[0].version===1&&observed.sessions[0].relationshipId===observed.relationships[0].id,'p03_composition_db_summary');
   write('composition-database-observation.json',observed,true);
   return observed;
  };

  const outcome=await exercise({sha,id,sql,apply,wait,transport,post,postExact,write,pass,users,newSession,api,anon,service,origin,setWriteRelease,writeCounts,attestComposition,observedAuth,observeCompositionDatabase,...((feedbackMode||assembledMode)?{readerSha:assembledMode?assembledCandidateSha:feedbackReaderSha,appliedMigrations:()=>s.migrations.map(x=>({...x}))}:{})});
  if(browserMode){browserReceipt=validateBrowserReceipt(outcome?.browser);write('browser-receipt.json',{sha,...browserReceipt});}
  transportGate.assertClean();const transportObservation={schema:'p03-owned-transport.v1',sha,runId:id,...transportGate.snapshot(),directPostCounts:Object.fromEntries(directPostCounts)};check(transportObservation.authorizedPostRequests===35&&transportObservation.sdkReads>=9&&transportObservation.sdkReads<=36,'p03_composition_actual_transport_counts');write('transport-observation.json',transportObservation,true);
  compositionObserved=outcome.composition;check(compositionObserved?.schema==='p03-composition-observed.v1'&&compositionObserved.runId===id&&compositionObserved.appSha===sha,'p03_composition_outcome_binding');write('composition-observed.json',{sha,...compositionObserved},true);write('auth-observations.json',observedAuth(),true);
  await attest();cleanup='PENDING';
 }finally{
  await stopHost();
  for(const resource of [...s.resources].reverse()){const obj=JSON.parse(docker(resource.type==='network'?['network','inspect',resource.name]:['inspect',resource.name]))[0];check((resource.type==='network'?obj.Labels:obj.Config.Labels)?.[label]===id,'pf10_native_cleanup_owner');docker(resource.type==='network'?['network','rm',resource.name]:['rm','-f','-v',resource.name]);}
  cleanup='REMOVED_OWNED_RESOURCES';write('cleanup.json',{runId:id,sha,cleanup});console.log(config.logPrefix+'_NATIVE_CLEANUP '+JSON.stringify({sha,runId:id,status:cleanup,resources:s.resources.length}));
 }
 transportGate.assertClean();
 check(results.length===(browserMode?config.browserPhases:config.phases)&&cleanup==='REMOVED_OWNED_RESOURCES','pf10_native_incomplete_acceptance');
 console.log(config.logPrefix+'_NATIVE_AUTH '+JSON.stringify({sha,status:'PASS_BOUNDED_P03_COMPOSITION_NATIVE',fullAssembledAcceptance:'NOT_ESTABLISHED',remaining:['P09-workbook-unknown-save-not-covered-on-e0','destination-install-and-Arash-acceptance'],compositionProofSha256:hash(readFileSync(resolve(privateDir,'composition-observed.json'))),transportProofSha256:hash(readFileSync(resolve(privateDir,'transport-observation.json'))),allocationId:process.env.ASSEMBLED_NATIVE_ALLOCATION_ID,scenarios:results.length,cleanup,memberAuth:'real GoTrue-issued JWT validated by PostgREST and native Next/SSR routes',schema:'candidate in owned tmpfs only',targetInstall:'NOT_APPLIED',browser:browserReceipt?.status??'NOT_RUN',...(browserReceipt?{browserReceipt}:{}),...((feedbackMode||assembledMode)?{acceptance,readerSha:assembledMode?assembledCandidateSha:feedbackReaderSha}:{}),arashAcceptance:'UNOBSERVED',privateArtifactsUploaded:false}));
}
