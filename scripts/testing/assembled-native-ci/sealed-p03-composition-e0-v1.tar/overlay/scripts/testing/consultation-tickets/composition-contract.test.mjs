import test from 'node:test';
import assert from 'node:assert/strict';
import { createProductAdmission, createBrowserForwardGate, paths, phases, budget, app, origin, validateCompositionEvidence, canonicalFinancialHash } from './composition-contract.mjs';
const ids = Object.fromEntries(['a','b','owner','admin'].map((a,i)=>[a,`00000000-0000-4000-8000-00000000000${i+1}`]));
const input=(actor,token)=>JSON.stringify({expectedActorId:ids[actor],clientToken:token});
test('shared API/browser admission consumes a token before an uncertain result; a new channel cannot replay it',()=>{
 const journal=[], admission=createProductAdmission(ids,x=>journal.push(x));
 admission.admit('a',origin+'/api/consultation/tickets',input('a','one-token'));
 assert.throws(()=>admission.admit('a',origin+'/api/consultation/tickets',input('a','one-token')),/replay_forbidden/);
 assert.equal(journal.length,1);assert.equal(journal[0].body,input('a','one-token'));
 admission.stopUnknown();assert.throws(()=>admission.admit('a',origin+'/api/consultation/tickets',input('a','new-token')),/stopped/);
});
test('persistence failure cannot reach a second send even with a different token',()=>{
 const a=createProductAdmission(ids,()=>{throw Error('disk full');});
 assert.throws(()=>a.admit('a',origin+'/api/consultation',input('a','token-one')),/journal_failed_stop/);
 assert.throws(()=>a.admit('owner',origin+'/api/consultation',input('owner','token-two')),/stopped/);
 assert.equal(a.snapshot().total,1);assert.equal(a.snapshot().unresolved,1);
 assert.throws(()=>a.record('a',origin+'/api/consultation',input('a','token-one'),201),/stopped/);
});
test('every cap map is immutable, so callers cannot raise a route or actor ceiling',()=>{
 assert.equal(Object.isFrozen(paths),true);
 for(const caps of Object.values(paths)){assert.equal(Object.isFrozen(caps),true);assert.throws(()=>caps.admin=99,TypeError);}
 assert.throws(()=>paths['/api/consultation'].a=999,TypeError);
 const a=createProductAdmission(ids,()=>{});for(let i=0;i<4;i++)a.admit('a',origin+'/api/consultation',input('a','token-mutation-'+i));
 assert.throws(()=>a.admit('a',origin+'/api/consultation',input('a','token-mutation-over')),/post_cap/);
});
test('post-validation mutations to the supplied actor map cannot substitute an identity',()=>{
 const mutable={...ids},a=createProductAdmission(mutable,()=>{});mutable.a=ids.owner;delete mutable.owner;mutable.intruder=ids.admin;
 a.admit('a',origin+'/api/consultation',input('a','original-actor-token'));
 assert.throws(()=>a.admit('a',origin+'/api/consultation',input('owner','substitute-token')),/actor_identity/);
 a.admit('owner',origin+'/api/consultation',input('owner','original-owner-token'));
});
test('failed result persistence keeps the attempt unresolved and stops both admission and result retries',()=>{
 let sinks=0;const a=createProductAdmission(ids,row=>{sinks++;if(row.kind==='result')throw Error('result disk failure');});
 const url=origin+'/api/consultation',body=input('a','result-failure-token');a.admit('a',url,body);
 assert.throws(()=>a.record('a',url,body,201),/journal_failed_stop/);
 assert.deepEqual({stopped:a.snapshot().stopped,unresolved:a.snapshot().unresolved,positive:a.snapshot().positive,denied:a.snapshot().denied},{stopped:true,unresolved:1,positive:0,denied:0});
 assert.throws(()=>a.admit('owner',url,input('owner','different-token')),/stopped/);
 assert.throws(()=>a.record('a',url,body,201),/stopped/);assert.equal(sinks,2);
});
test('a successful response is counted only after synchronous result persistence completes',()=>{
 let a;const observed=[];a=createProductAdmission(ids,row=>{if(row.kind==='result')observed.push(a.snapshot());});
 const url=origin+'/api/consultation',body=input('a','result-success-token');a.admit('a',url,body);a.record('a',url,body,201);
 assert.equal(observed[0].unresolved,1);assert.equal(observed[0].positive,0);assert.equal(a.snapshot().unresolved,0);assert.equal(a.snapshot().positive,1);
});
test('asynchronous persistence is refused before transport',()=>{
 const a=createProductAdmission(ids,()=>Promise.resolve());
 assert.throws(()=>a.admit('a',origin+'/api/consultation',input('a','token-one')),/journal_failed_stop/);
});
test('an admitted but unconfirmed write remains unresolved; a changed body cannot certify its result',()=>{
 const journal=[],a=createProductAdmission(ids,x=>journal.push(x)),url=origin+'/api/consultation';
 a.admit('a',url,input('a','token-one'));assert.equal(a.snapshot().unresolved,1);
 assert.throws(()=>a.record('a',url,JSON.stringify({...JSON.parse(input('a','token-one')),command:'changed'}),201),/result_binding/);
 a.record('a',url,input('a','token-one'),201);assert.equal(a.snapshot().unresolved,0);assert.equal(a.snapshot().positive,1);
 assert.equal(journal[1].kind,'result');assert.throws(()=>a.record('a',url,input('a','token-one'),201),/result_binding/);
});
test('all six route caps bind actors and include denied attempts; the 27th POST is rejected',()=>{
 const a=createProductAdmission(ids,()=>{});let token=0;
 for(const [path,caps] of Object.entries(paths)) for(const [actor,cap] of Object.entries(caps)){
   for(let i=0;i<cap;i++)a.admit(actor,origin+path,input(actor,'token-'+String(++token).padStart(4,'0')));
   assert.throws(()=>a.admit(actor,origin+path,input(actor,'over-cap-token')),/post_cap/);
 }
 assert.equal(token,26);assert.equal(a.snapshot().total,26);
});
test('unrelated admin, unrelated member and actor substitution never gain product write admission',()=>{
 const a=createProductAdmission(ids,()=>{});
 for(const actor of ['b','admin'])for(const path of Object.keys(paths))assert.throws(()=>a.admit(actor,origin+path,input(actor,'actor-token')),/actor_path/);
 assert.throws(()=>a.admit('a',origin+'/api/consultation',input('owner','actor-token')),/actor_identity/);
});
test('foreign origins, URL normalization, credentials, workbook and unknown routes fail before persistence',()=>{
 let writes=0;const a=createProductAdmission(ids,()=>writes++);
 for(const path of ['https://portfolio.example/api/consultation',origin+'/x/../api/consultation',origin+'/api/%63onsultation',origin+'/api/consultation?x=1',origin+'/api/admin/intelligence/workbooks',origin+'/api/consultation#secret','http://u:p@localhost:32189/api/consultation'])assert.throws(()=>a.admit('a',path,input('a','token-one')),/destination/);
 assert.equal(writes,0);
});
const syntheticFutureEvidence=()=>({
 schema:'p03-composition-e0.v1',appSha:app.sha,appTree:app.tree,sameOwnedContext:true,sameRelationship:true,actors:4,tmpfsVerified:true,
 productServiceRight:'NOT_CONNECTED',targetInstall:'NOT_APPLIED',arashAcceptance:'UNOBSERVED',phases:phases.map(name=>({name,status:'PASS'})),
 summary:{writeMode:'native-api-dom-read',version:1,id:ids.a,contentHash:'a'.repeat(64),exactTicketLink:true,privateNoteAbsent:true,freshSessionDomRead:true},
 unknownScope:'P03-ticket-only',p09UnknownSave:'NOT_COVERED_MISSING_JOURNAL',p09HistoricalAcceptanceTransferred:false,
 ...Object.fromEntries(['commandLoss','preparationLoss'].map(name=>[name,{actualStatus:201,contextDestroyedBeforeConfirmation:true,freshPasswordSdkSession:true,sameServerBodyAndToken:true,recoveryCommandPosts:0,recoveryPreparationPosts:0,storedEvents:name==='commandLoss'?1:0,transportClaim:'response-stage-context-destruction'}])),
 feedback:{statuses:['doing','done'],originalRowsStable:true,beforeFinancialHash:'b'.repeat(64),afterFinancialHash:'b'.repeat(64)},
 basisChange:{afterFeedbackProof:true,realHoldingVersion:2,originalSummaryBasisRetained:true,replyReadOnlyReason:'basis_changed',deniedReplyStatus:409},
 isolation:{unrelatedMemberDenied:true,unrelatedAdminDenied:true,revokedAdvisorDenied:true,memberHistoryRetained:true},
 counts:{productPosts:26,positive:24,denied:2,replayedPosts:0,modelCalls:0,workbookPosts:0,authCreate:4,authPassword:9,authLogout:4,negativeRpc:1},
 cleanup:{status:'CONFIRMED',independentReadback:true,fallbackUsed:false},
});
test('future receipt projection accepts only this explicitly synthetic complete contract example',()=>{
 assert.equal(validateCompositionEvidence(syntheticFutureEvidence()).status,'PASS_BOUNDED_P03_COMPOSITION');
});
test('old 14-check bounded receipt cannot stand in for a composed run',()=>{
 assert.throws(()=>validateCompositionEvidence({status:'PASS_BOUNDED_ASSEMBLED_NATIVE',appSha:app.sha,checks:14}),/source_binding/);
});
test('a missing fresh-login phase or summary publication cannot be projected as completed',()=>{
 const a=syntheticFutureEvidence();a.phases=a.phases.filter(x=>x.name!=='fresh-session-summary-history');assert.throws(()=>validateCompositionEvidence(a),/phase_missing/);
 const b=syntheticFutureEvidence();delete b.summary.exactTicketLink;assert.throws(()=>validateCompositionEvidence(b),/summary_binding/);
});
test('financial feedback mutation fails even if totals happen to remain equal',()=>{
 const before=[{id:ids.a,balance:10,source:'original'}],after=[{id:ids.a,balance:10,source:'changed'}];
 const a=syntheticFutureEvidence();a.feedback.beforeFinancialHash=canonicalFinancialHash(before);a.feedback.afterFinancialHash=canonicalFinancialHash(after);
 assert.throws(()=>validateCompositionEvidence(a),/feedback_financial_change/);
});
test('P03 success never imports historical P09 journal acceptance',()=>{
 const a=syntheticFutureEvidence();a.p09UnknownSave='PASS';assert.throws(()=>validateCompositionEvidence(a),/p09_scope/);
 const b=syntheticFutureEvidence();b.p09HistoricalAcceptanceTransferred=true;assert.throws(()=>validateCompositionEvidence(b),/p09_scope/);
});
test('replayed unknown write, TCP-cut overclaim and missing cleanup readback each fail closed',()=>{
 for(const edit of [v=>v.commandLoss.recoveryCommandPosts=1,v=>v.preparationLoss.transportClaim='tcp-cut',v=>delete v.cleanup.independentReadback]){
  const a=syntheticFutureEvidence();edit(a);assert.throws(()=>validateCompositionEvidence(a));
 }
});
test('missing Auth counters stay unknown and never become a zero-valued success',()=>{
 for(const key of ['authPassword','authLogout']){const a=syntheticFutureEvidence();delete a.counts[key];assert.throws(()=>validateCompositionEvidence(a),/counts/);}
});
test('time budget includes cleanup and reserve without enlarging the root controller',()=>{
 assert.equal(budget.provisionMinutes+budget.flowMinutes+budget.recoveryMinutes+budget.isolationMinutes+budget.cleanupMinutes+budget.reserveMinutes,budget.totalMinutes);
});
test('browser Auth and REST mutations stop before forwarding, with no subsequent admission or retry',async()=>{
 const routes=['/auth/v1/token','/auth/v1/logout','/rest/v1/rpc/command_consultation','/rest/v1/profiles','/api/unknown'];
 for(const path of routes)for(const method of ['POST','PUT','PATCH','DELETE']){
  const a=createProductAdmission(ids,()=>{}),gate=createBrowserForwardGate(a,()=>true);let calls=0;
  await assert.rejects(gate('a',origin+path,method,input('a','browser-attack-token'),()=>calls++));
  assert.equal(calls,0);assert.equal(a.snapshot().total,0);assert.equal(a.snapshot().stopped,true);
  await assert.rejects(gate('a',origin+'/api/consultation','POST',input('a','later-browser-token'),()=>calls++),/stopped/);
  assert.throws(()=>a.admit('owner',origin+'/api/consultation',input('owner','later-api-token')),/stopped/);assert.equal(calls,0);
 }
});
test('PUT/PATCH/DELETE/OPTIONS on an otherwise permitted product route cannot bypass POST admission',async()=>{
 for(const method of ['PUT','PATCH','DELETE','OPTIONS']){const a=createProductAdmission(ids,()=>{}),gate=createBrowserForwardGate(a,()=>true);let calls=0;
  await assert.rejects(gate('a',origin+'/api/consultation',method,input('a','wrong-method-token'),()=>calls++),/browser_mutation_forbidden/);
  assert.equal(calls,0);assert.equal(a.snapshot().stopped,true);assert.equal(a.snapshot().total,0);}
});
test('only an exact product POST from an allowed actor forwards after its durable admission',async()=>{
 const journal=[],a=createProductAdmission(ids,row=>journal.push(row)),gate=createBrowserForwardGate(a,()=>false);let calls=0;
 await gate('a',origin+'/api/consultation','POST',input('a','allowed-browser-token'),()=>{assert.equal(journal[0].kind,'intent');assert.equal(a.snapshot().total,1);calls++;});
 assert.equal(calls,1);assert.equal(a.snapshot().unresolved,1);
 const other=createProductAdmission(ids,()=>{}),denied=createBrowserForwardGate(other,()=>true);let foreign=0;
 await assert.rejects(denied('admin',origin+'/api/consultation','POST',input('admin','forbidden-browser-token'),()=>foreign++),/actor_path/);
 assert.equal(foreign,0);assert.equal(other.snapshot().stopped,true);
});
test('navigation and summary read-only gates permit needed GET/HEAD but stop every POST before forward',async()=>{
 const a=createProductAdmission(ids,()=>{}),gate=createBrowserForwardGate(a,(url,method)=>url===origin+'/dashboard'&&['GET','HEAD'].includes(method),true);let calls=0;
 for(const method of ['GET','HEAD'])await gate('a',origin+'/dashboard',method,undefined,()=>calls++);
 assert.equal(calls,2);
 await assert.rejects(gate('a',origin+'/api/consultation','POST',input('a','read-only-token'),()=>calls++),/browser_mutation_forbidden/);
 assert.equal(calls,2);assert.equal(a.snapshot().total,0);assert.equal(a.snapshot().stopped,true);
});
