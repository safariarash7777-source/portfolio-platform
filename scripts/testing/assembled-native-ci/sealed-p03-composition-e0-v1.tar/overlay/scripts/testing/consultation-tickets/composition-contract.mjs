// Source proposal only. No CLI, transport, SQL, browser or lifecycle side effects.
// The root-owned runtime must bind this to existing P03 phases before execution.
import { createHash } from 'node:crypto';

export const app = Object.freeze({ sha: 'e0b930927563d7f9f6d79e848917c4ba0d77ed6f', tree: 'c6c67f2a78cd2cf672cf4f489f81e7f14cb041da' });
export const origin = 'http://localhost:32189';
export const actors = Object.freeze(['a', 'b', 'owner', 'admin']);
export const phases = Object.freeze([
  'owned-preflight', 'real-login-member-navigation', 'nonzero-dossier-consent',
  'default-service-closed', 'owned-server-cap', 'request-201-lost-get-only',
  'advisor-response-member-followup', 'published-summary-exact-ticket-link',
  'question-reply-and-feedback', 'fresh-session-summary-history',
  'command-201-destroy-get-only', 'preparation-201-destroy-zero-command',
  'feedback-financial-stability', 'explicit-financial-basis-change',
  'isolation-revoke-history', 'independent-owned-cleanup',
]);
export const paths = Object.freeze(Object.fromEntries(Object.entries({
  '/api/portfolio/holdings': { a: 2 },
  '/api/personal-finance/cash-flow': { a: 1 },
  '/api/consultation': { a: 4, owner: 5 },
  '/api/consultation/tickets': { a: 3, owner: 2 },
  '/api/consultation/ticket-attempts': { a: 5, owner: 2 },
  '/api/consultation/replies': { owner: 2 },
}).map(([path,caps])=>[path,Object.freeze(caps)])));
export const budget = Object.freeze({ productPosts: 26, expectedPositive: 24, expectedDenied: 2,
  authCreate: 4, authPassword: 9, authLogout: 4, negativeRpc: 1,
  totalMinutes: 25, provisionMinutes: 5, flowMinutes: 9, recoveryMinutes: 4,
  isolationMinutes: 2, cleanupMinutes: 3, reserveMinutes: 2,
  modelCalls: 0, workbookPosts: 0, automaticRetries: 0 });

const fail = code => { throw Error('p03_composition_' + code); };
const hash = value => createHash('sha256').update(value).digest('hex');
const canonical = value => value === null || typeof value !== 'object' ? JSON.stringify(value)
  : Array.isArray(value) ? '[' + value.map(canonical).join(',') + ']'
    : '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';

// One shared admission object for direct API and browser CDP, BEFORE forwarding.
// Persist is the existing exclusive, fsync'ed private journal, never a public log.
// A persistence failure consumes the attempt and stops all future admissions.
export function createProductAdmission(ids, persist) {
  if (!ids || typeof ids !== 'object' || Array.isArray(ids)) fail('actor_binding');
  const actorIds=Object.freeze({...ids});
  if (typeof persist !== 'function' || Object.keys(actorIds).sort().join() !== [...actors].sort().join()
      || new Set(Object.values(actorIds)).size !== 4 || !Object.values(actorIds).every(v => typeof v === 'string' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(v))) fail('actor_binding');
  const counts = new Map(), attempts = new Map(); let total = 0, stopped = false, positive = 0, denied = 0;
  return Object.freeze({
    admit(actor, value, rawBody) {
      if (stopped) fail('stopped');
      let url, body; try { url = new URL(value); body = JSON.parse(rawBody); } catch { fail('request_shape'); }
      const rawPath = value.slice(origin.length).split('?')[0];
      if (url.origin !== origin || url.username || url.password || url.hash || url.search || /[%\\\s]/.test(rawPath)
          || rawPath !== url.pathname || !Object.hasOwn(paths, url.pathname)) fail('destination');
      if (!body || typeof body !== 'object' || Array.isArray(body)) fail('request_shape');
      const cap = paths[url.pathname][actor]; if (!cap) fail('actor_path');
      if ((body.expectedActorId ?? body.expectedOwnerId ?? actorIds[actor]) !== actorIds[actor]) fail('actor_identity');
      const token = body.clientToken ?? body.client_token;
      if (typeof token !== 'string' || token.length < 8 || token.length > 200) fail('token');
      const key = actor + ':' + url.pathname + ':' + token;
      if (attempts.has(key)) fail('replay_forbidden');
      const counter = actor + ':' + url.pathname, count = counts.get(counter) ?? 0;
      if (count >= cap || total >= budget.productPosts) fail('post_cap');
      counts.set(counter, count + 1); total++; attempts.set(key,{ordinal:total,status:null,url:value,bodyHash:hash(rawBody)});
      try {
        const receipt = persist({ kind:'intent', ordinal: total, actor, path: url.pathname, body: rawBody, bodySha256: hash(rawBody), token });
        if (receipt && typeof receipt.then === 'function') throw Error('async_persist');
      } catch { stopped = true; fail('journal_failed_stop'); }
      return Object.freeze({ ordinal: total, bodySha256: hash(rawBody) });
    },
    record(actor, value, rawBody, status) {
      if(stopped)fail('stopped');
      let url,body;try{url=new URL(value);body=JSON.parse(rawBody);}catch{fail('result_shape');}
      const key=actor+':'+url.pathname+':'+(body.clientToken??body.client_token),attempt=attempts.get(key);
      if(!attempt||attempt.status!==null||attempt.url!==value||attempt.bodyHash!==hash(rawBody)||![200,201,409,503].includes(status))fail('result_binding');
      try{const result=persist({kind:'result',ordinal:attempt.ordinal,status});if(result&&typeof result.then==='function')throw Error('async_persist');}
      catch{stopped=true;fail('journal_failed_stop');}
      attempt.status=status;
      if(status===200||status===201)positive++;else denied++;
    },
    stopUnknown() { stopped = true; },
    snapshot() { return { total, counts: Object.fromEntries(counts), stopped,positive,denied,unresolved:[...attempts.values()].filter(x=>x.status===null).length }; },
  });
}

// Every browser request passes here BEFORE its existing CDP/route forward.
// Auth creation/login/logout and the negative RPC belong only to the bound
// direct runtime. Browser Auth/REST writes, other methods and unknown routes
// stop the shared run even if the legacy destination predicate allows them.
export function createBrowserForwardGate(admission, allowRead, readOnly=false) {
  if(typeof allowRead!=='function'||typeof readOnly!=='boolean')fail('browser_gate_binding');
  return async function forwardBrowser(actor,url,method,body,forward) {
    if(admission.snapshot().stopped)fail('stopped');
    try {
      if(typeof forward!=='function')fail('browser_forward_binding');
      if(method==='GET'||method==='HEAD') {
        if(!allowRead(url,method))fail('browser_read_destination');
      } else {
        if(readOnly||method!=='POST')fail('browser_mutation_forbidden');
        admission.admit(actor,url,body);
      }
    } catch(error) { admission.stopUnknown();throw error; }
    try{return await forward();}catch(error){admission.stopUnknown();throw error;}
  };
}

// This is a future receipt validator, never evidence that a native run happened.
// Unknown values and absent fields fail closed instead of becoming false/zero.
export function validateCompositionEvidence(value) {
  const v = value;
  if (!v || v.schema !== 'p03-composition-e0.v1' || v.appSha !== app.sha || v.appTree !== app.tree) fail('source_binding');
  if (v.sameOwnedContext !== true || v.sameRelationship !== true || v.actors !== 4 || v.tmpfsVerified !== true) fail('owned_binding');
  if (v.productServiceRight !== 'NOT_CONNECTED' || v.targetInstall !== 'NOT_APPLIED' || v.arashAcceptance !== 'UNOBSERVED') fail('scope');
  if (v.phases?.length !== phases.length || phases.some((name, i) => v.phases[i]?.name !== name || v.phases[i]?.status !== 'PASS')) fail('phase_missing');
  if (v.summary?.writeMode !== 'native-api-dom-read' || v.summary.version !== 1 || !v.summary.id
      || !/^[a-f0-9]{64}$/.test(v.summary.contentHash ?? '') || v.summary.exactTicketLink !== true
      || v.summary.privateNoteAbsent !== true || v.summary.freshSessionDomRead !== true) fail('summary_binding');
  if (v.unknownScope !== 'P03-ticket-only' || v.p09UnknownSave !== 'NOT_COVERED_MISSING_JOURNAL'
      || v.p09HistoricalAcceptanceTransferred !== false) fail('p09_scope');
  for (const name of ['commandLoss', 'preparationLoss']) {
    const r = v[name];
    if (!r || r.actualStatus !== 201 || r.contextDestroyedBeforeConfirmation !== true || r.freshPasswordSdkSession !== true
        || r.sameServerBodyAndToken !== true || r.recoveryCommandPosts !== 0 || r.recoveryPreparationPosts !== 0
        || r.storedEvents !== (name === 'commandLoss' ? 1 : 0) || r.transportClaim !== 'response-stage-context-destruction') fail(name);
  }
  if (!v.feedback || v.feedback.statuses?.join() !== 'doing,done' || v.feedback.originalRowsStable !== true
      || typeof v.feedback.beforeFinancialHash !== 'string' || !/^[a-f0-9]{64}$/.test(v.feedback.beforeFinancialHash)
      || v.feedback.beforeFinancialHash !== v.feedback.afterFinancialHash) fail('feedback_financial_change');
  if (v.basisChange?.afterFeedbackProof !== true || v.basisChange.realHoldingVersion !== 2
      || v.basisChange.originalSummaryBasisRetained !== true || v.basisChange.replyReadOnlyReason !== 'basis_changed'
      || v.basisChange.deniedReplyStatus !== 409) fail('basis_change');
  if (v.isolation?.unrelatedMemberDenied !== true || v.isolation.unrelatedAdminDenied !== true
      || v.isolation.revokedAdvisorDenied !== true || v.isolation.memberHistoryRetained !== true) fail('isolation');
  if (v.counts?.productPosts !== budget.productPosts || v.counts.positive !== budget.expectedPositive
      || v.counts.denied !== budget.expectedDenied || v.counts.replayedPosts !== 0 || v.counts.modelCalls !== 0
      || v.counts.workbookPosts !== 0 || v.counts.authCreate !== 4 || !Number.isSafeInteger(v.counts.authPassword) || v.counts.authPassword > 9
      || v.counts.authPassword < 4 || !Number.isSafeInteger(v.counts.authLogout) || v.counts.authLogout < 0 || v.counts.authLogout > 4 || v.counts.negativeRpc !== 1) fail('counts');
  if (v.cleanup?.status !== 'CONFIRMED' || v.cleanup.independentReadback !== true || v.cleanup.fallbackUsed !== false) fail('cleanup');
  return { status: 'PASS_BOUNDED_P03_COMPOSITION', appSha: app.sha, unknownScope: v.unknownScope,
    p09UnknownSave: v.p09UnknownSave, targetInstall: v.targetInstall, arashAcceptance: v.arashAcceptance };
}

export function canonicalFinancialHash(rows) { return hash(canonical(rows)); }

export const compositionNativeChecks=Object.freeze(["isolation-attested", "four-fresh-auth-users-and-sdk-getuser", "browser-owned-nonzero-dossier-real-consent", "assembled-real-member-navigation-and-read-only-dom", "browser-real-consumer-checked", "composition-summary-published-exact-link", "composition-question-reply-and-feedback", "composition-fresh-summary-dom-get-only", "composition-feedback-stable-before-basis-change", "composition-financial-basis-change-readonly", "composition-isolation-revocation-history", "composition-auth-api-cdp-counts", "composition-owned-browser-cleanup"]);
