// SAME parent lifecycle transport boundary. Pure constructor, no fetch on import.
// Only its closed write() is used AFTER parent post() journals/caps the request.
export function createOwnedTransportGate({origin,allowDestination,forward,journalReject}){
 const check=v=>{if(!v)throw Error('p03_composition_transport_binding');};
 check(origin==='http://localhost:32189'&&typeof allowDestination==='function'&&typeof forward==='function'&&typeof journalReject==='function');
 const state={poisoned:false,rejected:0,readRequests:0,authorizedPostRequests:0,sdkReads:0};
 const reject=code=>{
  state.poisoned=true;state.rejected++;
  try{const value=journalReject({ordinal:state.rejected,code});if(value&&typeof value.then==='function')throw Error('async_journal');}
  catch{throw Error('p03_composition_transport_rejection_journal_failed');}
  throw Error('p03_composition_transport_poisoned');
 };
 const assertClean=()=>{if(state.poisoned)throw Error('p03_composition_transport_poisoned');};
 const request=(value,options={})=>{
  let url;try{url=new URL(typeof value==='string'?value:value?.url??String(value));}catch{return reject('INVALID_URL');}
  const method=String(options.method??value?.method??'GET').toUpperCase();
  if(url.origin!==origin||url.username||url.password||url.hash)return reject('FOREIGN_DESTINATION');
  return{url,method};
 };
 const read=(value,options={})=>{
  assertClean();const{url,method}=request(value,options);
  if(!['GET','HEAD'].includes(method)||options.body!=null||value?.body!=null)return reject('UNJOURNALED_MUTATION');
  let target;try{target=allowDestination(url.href,method);}catch{return reject('READ_DESTINATION');}
  state.readRequests++;return forward(target,{...options,method});
 };
 const write=async(value,options={})=>{
  assertClean();const{url,method}=request(value,options);
  if(method!=='POST')return reject('UNEXPECTED_WRITE_METHOD');
  let target;try{target=allowDestination(url.href,method);}catch{return reject('WRITE_DESTINATION');}
  state.authorizedPostRequests++;
  try{return await forward(target,{...options,method:'POST'});}catch{return reject('WRITE_OUTCOME_UNKNOWN');}
 };
 const sdkRead=(actorId,accessToken,anon,value,options={})=>{
  assertClean();const{url,method}=request(value,options);
  if(!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(actorId)||typeof accessToken!=='string'||typeof anon!=='string')return reject('SDK_ACTOR_BINDING');
  if(!['GET','HEAD'].includes(method)||url.pathname!=='/auth/v1/user'||url.search||options.body!=null||value?.body!=null)return reject('SDK_READ_ONLY');
  const headers=new Headers(value?.headers);new Headers(options.headers).forEach((v,k)=>headers.set(k,v));
  if(headers.get('authorization')!=='Bearer '+accessToken||headers.get('apikey')!==anon)return reject('SDK_SESSION_BINDING');
  if(state.sdkReads>=36)return reject('SDK_READ_CAP');state.sdkReads++;
  return read(url.href,{...options,method,headers});
 };
 return Object.freeze({read,write,sdkRead,reject,assertClean,snapshot:()=>Object.freeze({...state})});
}
