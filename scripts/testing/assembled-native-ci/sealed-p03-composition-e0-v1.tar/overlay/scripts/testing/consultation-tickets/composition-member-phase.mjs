// Test-only composition phase. Called by the existing real browser case after
// its real advisor response/member followup, in the SAME owned ctx and relation.
// No runner, lifecycle, SQL, provider, endpoint fixture or automatic retry.
import { randomUUID } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { sdkCookies, storageAudit, browserDestination } from './browser.mjs';
import { requireOriginalFeedbackRows } from './feedback-reader-native.mjs';
import { createProductAdmission, createBrowserForwardGate, app, origin, canonicalFinancialHash } from './composition-contract.mjs';
import { assembledBrowserDestination } from './assembled-observer-policy.mjs';
const root=fileURLToPath(new URL('../../../',import.meta.url));
const load=async path=>{const m=await import(pathToFileURL(resolve(root,path)));return m.default??m;};
const check=(v,code)=>{if(!v)throw Error('p03_composition_'+code);};
const period={startOn:'2026-10-01',endOn:'2026-10-31'};

// Root must supply this attestation from its independently verified owned
// lifecycle. Missing evidence stops BEFORE any composition operation.
export function bindCompositionContext(ctx){
 const b=ctx.compositionBinding;
 check(b?.schema==='p03-composition-binding.v1'&&b.appSha===app.sha&&b.appTree===app.tree
   &&b.tmpfsVerified===true&&b.runId===ctx.id&&ctx.origin===origin
   &&b.authCreatedIds?.length===4&&new Set(b.authCreatedIds).size===4
   &&Object.values(ctx.users).every(u=>b.authCreatedIds.includes(u.id))
   &&b.initialPasswordLogins===4&&b.productServiceRight==='NOT_CONNECTED'&&b.serverWritesReleased===true,'root_binding_required');
 let authPasswords=b.initialPasswordLogins,authLogouts=0,negativeRpc=0,ordinal=0;
 const admission=createProductAdmission(Object.fromEntries(Object.entries(ctx.users).map(([a,u])=>[a,u.id])),row=>ctx.write('composition-'+row.kind+'-'+String(row.ordinal).padStart(3,'0')+'.json',row,true));
 const forwardBrowser=createBrowserForwardGate(admission,browserDestination);
 const forwardReadOnlyNav=createBrowserForwardGate(admission,assembledBrowserDestination,true);
 const forwardReadOnlySummary=createBrowserForwardGate(admission,(url,method)=>browserDestination(url,method,'feedback-reader-v1'),true);
 const wrapped={...ctx,
  forwardReadOnlyNav,forwardReadOnlySummary,
  async api(actor,path,body){
   check(!admission.snapshot().stopped,'shared_admission_stopped');
   if(body!==undefined)admission.admit(actor,origin+path,JSON.stringify(body));
   try{const result=await ctx.api(actor,path,body);if(body!==undefined)admission.record(actor,origin+path,JSON.stringify(body),result.status);return result;}catch(error){admission.stopUnknown();throw error;}
  },
  async newSession(actor){check(authPasswords<9,'password_cap');authPasswords++;return ctx.newSession(actor);},
  async post(path,body,headers){
   if(path==='/rest/v1/rpc/lookup_consultation_ticket_attempt'){
    check(negativeRpc===0&&headers?.Authorization==='Bearer '+ctx.users.b.session.token&&headers?.apikey===ctx.anon,'negative_rpc_binding');negativeRpc++;
    return ctx.post(path,body,headers);
   }
   check(path==='/auth/v1/logout'&&authLogouts<4,'raw_post_not_bound');authLogouts++;
   return ctx.post(path,body,headers);
  },
 };
 return {ctx:wrapped,forwardBrowser,recordBrowser:(actor,url,body,status)=>admission.record(actor,url,body,status),
  snapshot:()=>({...admission.snapshot(),authCreate:4,authPassword:authPasswords,authLogout:authLogouts,negativeRpc}),
  stopUnknown:()=>admission.stopUnknown()};
}

export async function compositionSummaryPhase(ctx,s,{relation,resourceId,fingerprint}){
 const contracts=await load('lib/consultation/contracts.ts'),tickets=await load('lib/consultation/tickets.ts');
 const preparation=await load('lib/consultation/ticketAttemptStorageContracts.ts'),reply=await load('lib/consultation/replies.ts');
 const expect=async(actor,path,body,status=body===undefined?200:201)=>{const r=await ctx.api(actor,path,body);check(r.status===status,'http_'+status);return r.value;};
 const read=async actor=>contracts.validateConsultationRead(await expect(actor,'/api/consultation?'+new URLSearchParams({...period,relationshipId:relation})),{actorId:ctx.users[actor].id,relationshipId:relation,period});
 const command=async(actor,command)=>{const input=contracts.validateConsultationRequest({contractVersion:'consultation-request.v1',expectedActorId:ctx.users[actor].id,clientToken:randomUUID(),command});return contracts.validateConsultationReceipt(await expect(actor,'/api/consultation',input),input);};
 const parent=await read('owner'),before=fingerprint();
 const keys=[randomUUID(),randomUUID()];
 const body={topic:'SYNTHETIC_COMPOSED_VERSIONED_SUMMARY',goal:'Software acceptance only',clientSummary:'SYNTHETIC_MEMBER_VISIBLE_SUMMARY',rationale:'Synthetic fixture only',limitations:'Not personal advice; no real member or model',reviewOn:'2099-12-31',basis:parent.dossier.basis,researchVersionIds:[],evidence:[{label:'Owned synthetic financial declaration',url:null,asOf:'2026-10-29'}],actions:keys.map((actionKey,i)=>({actionKey,title:i?'SYNTHETIC_ADVISOR_ACTION':'SYNTHETIC_MEMBER_ACTION',dueOn:'2099-12-31',responsible:i?'advisor':'member'}))};
 const privateNote='SYNTHETIC_COMPOSED_PRIVATE_OWNER_NOTE';
 const session=await command('owner',{kind:'save',relationshipId:relation,sessionKey:randomUUID(),baseVersion:0,body,privateNote});
 for(const kind of ['submit','approve','publish']){const current=(await read('owner')).sessions.find(x=>x.id===session.id);check(current,'summary_missing');await command('owner',{kind,relationshipId:relation,sessionId:session.id,contentHash:current.contentHash,note:null});}
 const published=(await read('a')).sessions.find(x=>x.id===session.id);
 check(published?.state==='published'&&published.version===1&&JSON.stringify(published.body.basis)===JSON.stringify(body.basis),'published_basis');
 const input=tickets.validateTicketRequest({contractVersion:'consultation-ticket-request.v1',expectedActorId:ctx.users.owner.id,clientToken:randomUUID(),command:{kind:'link_recommendation',relationshipId:relation,requestId:resourceId,baseVersion:2,recommendation:{sessionId:published.id,version:published.version,contentHash:published.contentHash}}});
 const exact=JSON.stringify(input);
 const prepared=await preparation.validateTicketPreparationReceipt(await expect('owner','/api/consultation/ticket-attempts',input),await read('owner'),exact);
 const linked=tickets.validateTicketReceipt(await expect('owner','/api/consultation/tickets',input),input);
 check(linked.version===3,'ticket_link_version');
 const direct=await ctx.post('/rest/v1/rpc/lookup_consultation_ticket_attempt',{p_relationship:relation,p_preparation:prepared.preparationId,p_client_token:null},{Authorization:'Bearer '+ctx.users.b.session.token,apikey:ctx.anon});
 check(direct.status===403,'foreign_rpc_denial');
 const question=await command('a',{kind:'feedback',relationshipId:relation,sessionId:session.id,actionKey:null,baseVersion:0,status:'question',text:'SYNTHETIC_VERSION_BOUND_MEMBER_QUESTION'});
 const replyInput=reply.validateReplyRequest({contractVersion:'consultation-reply-request.v1',expectedActorId:ctx.users.owner.id,clientToken:randomUUID(),command:{kind:'publish_reply',relationshipId:relation,sessionId:session.id,questionId:question.id,baseVersion:0,text:'SYNTHETIC_VERSION_BOUND_OWNER_REPLY',purpose:'clarification'}});
 const replyReceipt=reply.validateReplyReceipt(await expect('owner','/api/consultation/replies',replyInput),replyInput);
 for(const [i,actor,status] of [[0,'a','doing'],[1,'owner','done']])await command(actor,{kind:'feedback',relationshipId:relation,sessionId:session.id,actionKey:keys[i],baseVersion:0,status,text:null});
 const original=(await read('a')).actions.filter(x=>x.sessionId===session.id);
 check(original.length===3&&original.some(x=>x.status==='doing')&&original.some(x=>x.status==='done'),'feedback_rows');
 check(fingerprint()===before,'feedback_financial_change');
 const evidence={sessionId:session.id,version:1,contentHash:published.contentHash,requestId:resourceId,requestVersion:3,basis:body.basis,keys,original,beforeFinancialHash:canonicalFinancialHash(before),afterFinancialHash:canonicalFinancialHash(fingerprint()),writeMode:'native-api-dom-read',privateNote,foreignRpcDenied:true,replyReceipt};
 ctx.write('composition-summary-native.json',evidence,true);
 return {...evidence,exactTicketLink:true,privateNoteAbsent:true,originalRowsStable:true};
}

export async function compositionFreshSummaryRead(ctx,s,evidence,{relation,fingerprint}){
 const {privateNote,original}=evidence;
 const contracts=await load('lib/consultation/contracts.ts');
 const read=async actor=>{const r=await ctx.api(actor,'/api/consultation?'+new URLSearchParams({...period,relationshipId:relation}));check(r.status===200,'fresh_summary_read');return contracts.validateConsultationRead(r.value,{actorId:ctx.users[actor].id,relationshipId:relation,period});};
 const before=fingerprint(),body=(await read('a')).sessions.find(x=>x.id===evidence.sessionId).body;
 // Read actual session/feedback DOM after real logout/password SDK sessions.
 // Uses the existing P03 feedback reader's pages, cookies and storage audit.
 const dom=[];
 for(const actor of ['a','owner']){
  const logout=await ctx.post('/auth/v1/logout',{}, {Authorization:'Bearer '+ctx.users[actor].session.token,apikey:ctx.anon});check([200,204].includes(logout.status),'summary_logout');
  const old=ctx.users[actor].session.token;ctx.users[actor].session=await ctx.newSession(actor);check(old!==ctx.users[actor].session.token,'fresh_password');
  const context=await s.browser.newContext({serviceWorkers:'block',viewport:{width:actor==='a'?390:1440,height:900}});s.contexts.push(context);
  await context.addCookies(sdkCookies(ctx.users[actor].session.cookie));const page=await context.newPage();let blocked=false,posts=0,runtimeErrors=0;
  page.on('pageerror',()=>runtimeErrors++);
  await context.route('**/*',async route=>{const r=route.request();if(!['GET','HEAD'].includes(r.method()))posts++;try{await ctx.forwardReadOnlySummary(actor,r.url(),r.method(),r.postData(),()=>route.continue());}catch{blocked=true;s.asyncFailure='p03_composition_summary_browser_blocked';await route.abort();}});
  const path=actor==='a'?'/dashboard/consultation':'/admin/consultation';
  await page.goto(origin+path+'?'+new URLSearchParams({relation}),{waitUntil:'domcontentloaded'});
  await ctx.wait(()=>page.getByText(body.topic,{exact:true}).isVisible(),'p03_composition_summary_dom',60);
  for(let reload=0;reload<2;reload++){
   if(reload){await page.reload({waitUntil:'domcontentloaded'});await ctx.wait(()=>page.getByText(body.topic,{exact:true}).isVisible(),'p03_composition_summary_reload',60);}
   const card=page.locator('article[aria-label="جمع‌بندی نسخهٔ ۱"]');await card.locator('details summary').click();
   await ctx.wait(async()=>{const text=await card.innerText();return text.includes('SYNTHETIC_MEMBER_VISIBLE_SUMMARY')&&text.includes('در حال انجام')&&text.includes('انجام‌شده طبق اعلام')&&text.includes('SYNTHETIC_VERSION_BOUND_MEMBER_QUESTION')&&text.includes('SYNTHETIC_VERSION_BOUND_OWNER_REPLY');},'p03_composition_feedback_dom',60);
   const text=await card.innerText();check(actor!=='a'||!text.includes(privateNote),'private_note_leak');
  }
  const needles=[privateNote,body.clientSummary,'SYNTHETIC_VERSION_BOUND_MEMBER_QUESTION','SYNTHETIC_VERSION_BOUND_OWNER_REPLY',ctx.users[actor].session.token,...sdkCookies(ctx.users[actor].session.cookie).map(x=>x.value)];
  await storageAudit(page,needles);check(!blocked&&posts===0&&runtimeErrors===0,'fresh_dom_side_effect');
  dom.push({actor,realLogout:true,newPasswordSdkSession:true,actualReload:true,getOnly:true});await context.close();
 }
 requireOriginalFeedbackRows(original,(await read('a')).actions.filter(x=>x.sessionId===evidence.sessionId));
 check(fingerprint()===before,'feedback_financial_changed_after_dom');
 return {...evidence,freshDom:dom,exactTicketLink:true,privateNoteAbsent:true,originalRowsStable:true};
}

export async function compositionBasisChange(ctx,evidence,{relation,position,fingerprint}){
 const before=fingerprint();
 check(canonicalFinancialHash(before)===evidence.afterFinancialHash,'basis_change_before_feedback_proof');
 const current=await ctx.api('a','/api/portfolio/holdings');check(current.status===200&&current.value.version.version===1,'holding_v1');
 const input={base_version:1,client_token:randomUUID(),positions:[{...position,declared_value:1100000}],note:'Explicit owned basis-change test after feedback proof'};
 const changed=await ctx.api('a','/api/portfolio/holdings',input);check(changed.status===201&&changed.value.version===2,'holding_v2');
 const read=await ctx.api('owner','/api/consultation/replies?'+new URLSearchParams({relationshipId:relation,sessionId:evidence.sessionId}));
 check(read.status===200&&read.value.readOnlyReason==='basis_changed'&&read.value.canReply===false,'basis_reply_readonly');
 const denied={contractVersion:'consultation-reply-request.v1',expectedActorId:ctx.users.owner.id,clientToken:randomUUID(),command:{kind:'publish_reply',relationshipId:relation,sessionId:evidence.sessionId,questionId:evidence.original.find(x=>x.status==='question').id,baseVersion:1,text:'Must be rejected after basis change',purpose:'clarification'}};
 check((await ctx.api('owner','/api/consultation/replies',denied)).status===409,'basis_reply_denial');
 const member=await ctx.api('a','/api/consultation?'+new URLSearchParams({...period,relationshipId:relation}));
 const summary=member.value.sessions.find(x=>x.id===evidence.sessionId);check(JSON.stringify(summary.body.basis)===JSON.stringify(evidence.basis),'original_basis_changed');
 requireOriginalFeedbackRows(evidence.original,member.value.actions.filter(x=>x.sessionId===evidence.sessionId));
 return {expectedFinalFinancial:fingerprint(),afterFeedbackProof:true,realHoldingVersion:2,originalSummaryBasisRetained:true,replyReadOnlyReason:'basis_changed',deniedReplyStatus:409};
}
