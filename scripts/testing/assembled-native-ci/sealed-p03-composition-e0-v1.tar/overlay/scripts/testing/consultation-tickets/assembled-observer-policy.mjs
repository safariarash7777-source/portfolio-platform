import { assembledBrowserReadAllowed, origin } from './assembled-native-profile.mjs';

// Observer for the owned lab, not an authorization provider. Product writes
// remain forbidden. The existing SDK signout scenario alone needs Auth logout.
export function assembledBrowserDestination(value, method = 'GET') {
  try {
    if (typeof value !== 'string' || !value.startsWith(origin + '/')) return false;
    const raw = value.slice(origin.length).split('?')[0];
    if (/%(?:2e|2f|5c|25|00)/i.test(raw) || /[\\\u0000-\u0020]/.test(raw) || raw.split('/').some(x => x === '.' || x === '..')) return false;
    const u = new URL(value);
    if (u.origin !== origin || u.hash || u.username || u.password) return false;
    if (method === 'POST') return u.pathname === '/auth/v1/logout' && [...u.searchParams.keys()].length === 1 && u.searchParams.get('scope') === 'global';
    if (!['GET', 'HEAD'].includes(method)) return false;
    if (assembledBrowserReadAllowed(value, method, 'member') || assembledBrowserReadAllowed(value, method, 'advisor')) return true;
    return u.pathname === '/auth/v1/user' || u.pathname.startsWith('/rest/v1/') || ['/api/consultation', '/api/consultation/roster', '/api/consultation/replies', '/api/consultation/tickets', '/api/consultation/ticket-attempts', '/api/portfolio/holdings', '/api/portfolio/debts', '/api/portfolio/holdings/scope', '/api/personal-finance/cash-flow', '/api/personal-finance/goals'].includes(u.pathname);
  } catch { return false; }
}
