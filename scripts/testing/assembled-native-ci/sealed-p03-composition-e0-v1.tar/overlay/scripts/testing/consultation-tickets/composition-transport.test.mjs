import test from 'node:test';
import assert from 'node:assert/strict';
import {createOwnedTransportGate} from './composition-transport.mjs';
const origin='http://localhost:32189',actor='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const headers={authorization:'Bearer SYNTHETIC_TOKEN',apikey:'SYNTHETIC_ANON'};
function setup(){const calls=[],journal=[];const gate=createOwnedTransportGate({origin,allowDestination:(u)=>u,forward:(u,o)=>{calls.push({u,o});return Promise.resolve({status:200});},journalReject:r=>journal.push(r)});return{gate,calls,journal};}
test('SDK getUser/read is bound to the freshly issued actor token and goes through the shared read transport',async()=>{
 const{gate,calls}=setup();await gate.sdkRead(actor,'SYNTHETIC_TOKEN','SYNTHETIC_ANON',origin+'/auth/v1/user',{headers});
 assert.equal(calls.length,1);assert.equal(calls[0].o.method,'GET');assert.equal(gate.snapshot().sdkReads,1);assert.equal(gate.snapshot().readRequests,1);assert.equal(gate.snapshot().authorizedPostRequests,0);gate.assertClean();
});
test('SDK Auth refresh/logout, REST/RPC and all unwanted methods are rejected before forward and poison the run',()=>{
 const paths=['/auth/v1/token?grant_type=refresh_token','/auth/v1/logout','/rest/v1/profiles','/rest/v1/rpc/lookup_consultation_ticket_attempt'];
 for(const path of paths)for(const method of ['POST','PUT','PATCH','DELETE','OPTIONS']){
  const{gate,calls,journal}=setup();assert.throws(()=>gate.sdkRead(actor,'SYNTHETIC_TOKEN','SYNTHETIC_ANON',origin+path,{method,headers}),/transport_poisoned/);
  assert.equal(calls.length,0);assert.equal(gate.snapshot().rejected,1);assert.equal(gate.snapshot().poisoned,true);assert.equal(journal.length,1);
  assert.throws(()=>gate.sdkRead(actor,'SYNTHETIC_TOKEN','SYNTHETIC_ANON',origin+'/auth/v1/user',{headers}),/transport_poisoned/);
  assert.throws(()=>gate.assertClean(),/transport_poisoned/);assert.equal(calls.length,0);
 }
});
test('generic parent transport cannot perform a mutation or smuggle a POST through a Request object',()=>{
 for(const method of ['POST','PUT','PATCH','DELETE','OPTIONS']){const{gate,calls}=setup();assert.throws(()=>gate.read(origin+'/auth/v1/user',{method,headers}),/transport_poisoned/);assert.equal(calls.length,0);}
 const{gate,calls}=setup();const request=new Request(origin+'/auth/v1/logout',{method:'POST',headers});assert.throws(()=>gate.read(request),/transport_poisoned/);assert.equal(calls.length,0);
});
test('a swallowed SDK error cannot turn the final assertion or another authorized write into PASS',async()=>{
 const{gate,calls}=setup();try{gate.sdkRead(actor,'SYNTHETIC_TOKEN','SYNTHETIC_ANON',origin+'/auth/v1/logout',{method:'POST',headers});}catch{}
 assert.throws(()=>gate.assertClean(),/transport_poisoned/);await assert.rejects(gate.write(origin+'/api/consultation',{method:'POST'}),/transport_poisoned/);assert.equal(calls.length,0);assert.equal(gate.snapshot().authorizedPostRequests,0);
});
test('wrong SDK token or an unexpected GET resource poisons with zero forwarded requests',()=>{
 for(const init of [{value:origin+'/auth/v1/user',headers:{...headers,authorization:'Bearer WRONG'}},{value:origin+'/rest/v1/profiles',headers}]){
  const{gate,calls}=setup();assert.throws(()=>gate.sdkRead(actor,'SYNTHETIC_TOKEN','SYNTHETIC_ANON',init.value,{headers:init.headers}),/transport_poisoned/);assert.equal(calls.length,0);assert.equal(gate.snapshot().poisoned,true);
 }
});
test('direct journaled POST uses one closed write capability without counting a second transport call',async()=>{
 const{gate,calls}=setup();await gate.write(origin+'/auth/v1/token?grant_type=password',{method:'POST',headers,body:'SYNTHETIC_PASSWORD_BODY'});
 assert.equal(calls.length,1);assert.equal(gate.snapshot().authorizedPostRequests,1);assert.equal(gate.snapshot().sdkReads,0);gate.assertClean();
});
test('a failed rejection sink still poisons and permits no retry or forward',()=>{
 let calls=0;const gate=createOwnedTransportGate({origin,allowDestination:u=>u,forward:()=>calls++,journalReject:()=>{throw Error('disk full');}});
 assert.throws(()=>gate.read(origin+'/auth/v1/user',{method:'POST'}),/rejection_journal_failed/);assert.equal(calls,0);assert.throws(()=>gate.assertClean(),/transport_poisoned/);
});
test('unknown outcome of the one admitted direct POST stops further requests and writes',async()=>{
 let calls=0;const gate=createOwnedTransportGate({origin,allowDestination:u=>u,forward:()=>{calls++;throw Error('lost response');},journalReject:()=>{}});
 await assert.rejects(gate.write(origin+'/api/consultation',{method:'POST',body:'synthetic'}),/transport_poisoned/);assert.equal(calls,1);
 await assert.rejects(gate.write(origin+'/api/consultation',{method:'POST',body:'synthetic'}),/transport_poisoned/);assert.equal(calls,1);assert.throws(()=>gate.read(origin+'/auth/v1/user'),/transport_poisoned/);
});
