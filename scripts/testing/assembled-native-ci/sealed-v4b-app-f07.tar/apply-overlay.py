"""Install reviewed NEW test helpers in an exact isolated Linux Git copy only.

No native execution, SQL, Docker, Auth, account creation, fetch or package install.
The coordinator runs this only on the separately allocated isolated copy.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def apply(bundle, repo, expected_hash):
    if os.name != 'posix' or not Path('/proc').is_dir():
        raise ValueError('existing_isolated_linux_copy_required')
    base = bundle.resolve()
    raw = (base / 'scripts/testing/consultation-tickets/assembled-overlay.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_hash:
        raise ValueError('reviewed_driver_contract_required')
    contract = json.loads(raw)
    repo = repo.resolve(strict=True)
    git = lambda *args: subprocess.check_output(['git', *args], cwd=repo, stderr=subprocess.PIPE).decode().strip()
    if (git('rev-parse', 'HEAD') != contract['candidateCommit']
            or contract['candidateCommit'] != 'f07e0543c46cea88822dc0d400080b5bb94bef91'
            or git('rev-parse', 'HEAD^{tree}') != '8e43eab0bd66705b5455713ea15dd5c1d9c5f81a'
            or git('status', '--porcelain', '--untracked-files=no')):
        raise ValueError('isolated_copy_not_exact')
    names = {'assembled-auth-runtime.mjs', 'assembled-auth-gateway.mjs', 'assembled-native.mjs',
             'assembled-member-scenario.mjs', 'assembled-observer-policy.mjs', 'assembled-overlay-gate.mjs',
             'assembled-native-profile.mjs', 'assembled-native-source.json'}
    if len(contract['files']) != len(names):
        raise ValueError('overlay_file_set')
    planned = []
    seen = set()
    for pin in contract['files']:
        relative = Path(pin['path'])
        if (relative.parent.as_posix() != 'scripts/testing/consultation-tickets'
                or relative.name not in names or relative.name in seen):
            raise ValueError('overlay_path')
        seen.add(relative.name)
        source = base / relative
        target = repo / relative
        if (source.is_symlink() or not source.is_file() or target.parent.resolve() != repo / relative.parent
                or target.exists() or target.is_symlink() or git('ls-files', '--', relative.as_posix())):
            raise ValueError('overlay_existing_or_unsafe_file')
        value = source.read_bytes()
        if len(value) != pin['bytes'] or hashlib.sha256(value).hexdigest() != pin['sha256']:
            raise ValueError('overlay_hash')
        planned.append((target, value))
    target_contract = repo / 'scripts/testing/consultation-tickets/assembled-overlay.json'
    if target_contract.exists() or target_contract.is_symlink():
        raise ValueError('overlay_contract_exists_preserve_readback')
    # Complete read/validation before the first write. A partial filesystem copy
    # is never an execution receipt; inspect it before any recovery attempt.
    for target, value in planned + [(target_contract, raw)]:
        with target.open('xb') as handle:
            handle.write(value)
    return {'status': 'COPIED_NEW_HELPERS_ONLY', 'files': len(planned),
            'candidateCommit': contract['candidateCommit'], 'driverContractSha256': expected_hash,
            'nativeExecution': 'NOT_RUN', 'targetInstall': 'NOT_APPLIED'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--driver-contract-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(apply(args.bundle, args.repo, args.driver_contract_sha256)))
