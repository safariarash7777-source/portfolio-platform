# Child v4: frozen app f07, offline source packet only

This child derives from immutable v3 (SHA256 57d35ddc07e2883bb2dd5b0a7e051625a235c1294e3c5283e06ecec4438ccd81). The app is f07e0543c46cea88822dc0d400080b5bb94bef91,
tree 8e43eab0bd66705b5455713ea15dd5c1d9c5f81a: reviewed CI41755671173 and Preview dpl_CHscypUk9ywxHeSf35fNK4RDXzQY.
No native run, dispatch, controller adoption, dependency install, fixture write,
database, rights, new route, environment or Production change is performed here.

Only app commit/tree/source-object pins and their contract hashes change. Five other helper bodies remain byte-exact; the sixth changes only its candidate SHA
literal and is otherwise byte-exact after normalization. Actual stage observation,
14 native checks, 9 browser checks,
bounded POST allocation, timeout and owned cleanup rules remain byte-identical.
All 27 source fingerprints and 18 bootstrap SQL files remain exact. The 14 checks
still cover a bounded composition; fullflow and real service rights are not accepted.

Parent v3, app4dc, failed receipt41745964437 and all earlier receipts stay immutable.
This child excludes app4dc as its execution target, not as history. The prior Chrome
observation is SHA95dc9473b4f904cb3ab0800fc7206081fcae12abc094a088bd741a13f1747b72,
version156.0.8078.47, attested=false. A future real prepare may fail closed.
No earlier observation is promoted into a fresh runtime attestation.

Proposed controller/workflow/projector binding diffs are external review artifacts,
not adopted source. Controller adoption must preserve rootbae9's test-only fix and
receive its own exact source/CI gate. Existing historical v3 assertions must remain
valid against their frozen snapshot; updating that test wiring is a later review,
not a claim that this packet passed the current controller's v3-bound suite.
