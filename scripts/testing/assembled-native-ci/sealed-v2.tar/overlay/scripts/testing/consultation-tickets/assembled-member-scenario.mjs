// New bounded assembled consumer checks. Only the coordinator's owned tmpfs lab.
import { randomUUID, createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { sdkCookies, storageAudit } from './browser.mjs';
import { origin } from './assembled-native-profile.mjs';
import { assembledBrowserDestination } from './assembled-observer-policy.mjs';
export { assembledBrowserDestination } from './assembled-observer-policy.mjs';
const root = fileURLToPath(new URL('../../../', import.meta.url));
const check = (v, code) => { if (!v) throw Error(code); };
const quote = v => "'" + String(v).replaceAll("'", "''") + "'";
const digest = v => createHash('sha256').update(v).digest('hex');
const period = { startOn: '2026-10-01', endOn: '2026-10-31' };

export function financialFingerprint(ctx) {
  return ctx.sql('BEGIN READ ONLY;SELECT jsonb_build_object(' + ['member_holding_versions', 'member_holding_positions', 'member_debt_positions', 'member_cash_flow_versions', 'member_cash_flow_entries', 'member_goals_versions'].map(name => quote(name) + ",(SELECT encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]'),'UTF8')),'hex') FROM public." + name + ' r)').join(',') + ');COMMIT;');
}

export async function prepareMemberFixture(ctx) {
  const imported = async name => { const v = await import(pathToFileURL(resolve(root, name))); return v.default ?? v; };
  const contracts = await imported('lib/consultation/contracts.ts');
  const cash = await imported('lib/portfolio/cashFlowApiContract.ts');
  const expect = async (actor, path, body, status = body === undefined ? 200 : 201) => {
    const value = await ctx.api(actor, path, body);
    check(value.status === status, 'assembled_member_http_status'); return value.value;
  };
  const position = { position_key: 'assembled-synthetic-cash', manual_label: 'Synthetic assembled cash', symbol: null, asset_class: 'cash', qty: null, unit: 'item', as_of: '2026-10-29', title: 'Synthetic assembled declaration', ownership_pct: 100, valuation_mode: 'declared', declared_value: 1000000, currency: 'IRT', valuation_source: 'Synthetic declaration only', valuation_as_of: '2026-10-29', valuation_status: 'estimated' };
  // Existing transport persists each exact intent before its one POST. Unknown
  // transport outcomes stop the entire lab; no retry or grant provider is added.
  const holding = await expect('a', '/api/portfolio/holdings', { base_version: 0, client_token: randomUUID(), positions: [position], note: 'Owned assembled native fixture only' });
  const source = { label: 'Synthetic financial statement', observedOn: '2026-10-29' };
  const payload = { contractVersion: 1, period, accountDefinitions: [{ accountKey: 'synthetic-bank', label: 'Synthetic bank account' }], scopeAccountKeys: ['synthetic-bank'], opening: { amountToman: 500000, atStartOn: period.startOn, source }, coverage: { planned: { status: 'unknown', memberAffirmed: false, source: null }, actual: { status: 'complete', memberAffirmed: true, source } }, entries: [{ entryKey: 'income', basis: 'actual', kind: 'income', accountKey: 'synthetic-bank', amountToman: 100000, occurredOn: '2026-10-02', source, category: null, note: null }, { entryKey: 'expense', basis: 'actual', kind: 'expense', accountKey: 'synthetic-bank', amountToman: 20000, occurredOn: '2026-10-03', source, category: null, note: null }] };
  const input = cash.validateCashFlowWriteRequest({ contractVersion: 'cash-flow-request.v1', expectedOwnerId: ctx.users.a.id, clientToken: randomUUID(), baseVersion: 0, payload });
  const cashReceipt = cash.validateCashFlowReceipt(await expect('a', '/api/personal-finance/cash-flow', input), input);
  const own = await expect('a', '/api/portfolio/holdings');
  const other = await expect('b', '/api/portfolio/holdings');
  const cashRead = cash.validateCashFlowRead(await expect('a', '/api/personal-finance/cash-flow?' + new URLSearchParams(period)), { ownerId: ctx.users.a.id, period });
  check(holding.version === 1 && own.version.id === holding.version_id && own.positions[0]?.declared_value === 1000000 && Array.isArray(other.positions) && other.positions.length === 0 && cashRead.report.actual.closingToman === 580000 && cashRead.report.planned.netToman === null, 'assembled_member_independent_financial_readback');
  ctx.pass('assembled-financial-receipts-and-null-readback', { actualApiPosts: 2, canonicalReadback: true, unrelatedMemberEmpty: true, plannedUnknown: true, receiptDigests: [digest(JSON.stringify(holding)), digest(JSON.stringify(cashReceipt))] });
  ctx.sql(`INSERT INTO public.consultation_advisors(user_id,display_name,enabled,is_owner) VALUES(${quote(ctx.users.owner.id)},'Synthetic assembled owner',true,true);`);
  const request = contracts.validateConsultationRequest({ contractVersion: 'consultation-request.v1', expectedActorId: ctx.users.a.id, clientToken: randomUUID(), command: { kind: 'grant', advisorId: ctx.users.owner.id, clientLabel: 'Synthetic assembled member' } });
  const granted = contracts.validateConsultationReceipt(await expect('a', '/api/consultation', request), request);
  const relation = granted.id;
  const path = '/api/consultation?' + new URLSearchParams({ ...period, relationshipId: relation });
  const dossier = contracts.validateConsultationRead(await expect('owner', path), { actorId: ctx.users.owner.id, relationshipId: relation, period });
  check(dossier.dossier.basis.holdingsVersionId === holding.version_id && dossier.dossier.basis.cashFlowVersionId === cashReceipt.versionId && dossier.dossier.basis.goalsVersionId === null, 'assembled_member_exact_authorized_basis');
  await expect('b', path, undefined, 403); await expect('admin', path, undefined, 403);
  ctx.pass('assembled-consent-and-authorized-version-basis', { consentPosts: 1, advisorExactBasis: true, unrelatedMemberDenied: true, unrelatedAdminDenied: true, productServiceRight: 'NOT_CONNECTED' });
  return { relation, financialFingerprint: financialFingerprint(ctx) };
}

export async function inspectMemberNavigation(ctx, s) {
  const context = await s.browser.newContext({ serviceWorkers: 'block', viewport: { width: 390, height: 844 } });
  s.contexts.push(context); await context.addCookies(sdkCookies(ctx.users.a.session.cookie));
  const page = await context.newPage(); let blocked = false; const errors = [];
  page.on('pageerror', () => errors.push('runtime_error'));
  await context.route('**/*', async route => {
    if (!assembledBrowserDestination(route.request().url(), route.request().method())) { blocked = true; await route.abort(); return; }
    await route.continue();
  });
  await page.goto(origin + '/dashboard', { waitUntil: 'domcontentloaded' });
  const holdingsLink = page.locator('a[href="/dashboard/holdings"]').first();
  await holdingsLink.click();
  await ctx.wait(() => page.getByRole('heading', { name: 'دارایی، بدهی و خالص ثروت', exact: true }).isVisible(), 'assembled_member_holdings_dom', 60);
  check((await page.textContent('body')).includes('Synthetic assembled cash'), 'assembled_member_holding_not_mounted');
  await page.getByRole('link', { name: 'بازگشت به داشبورد', exact: true }).click();
  await page.locator('a[href="/dashboard/consultation"]').first().click();
  await ctx.wait(() => page.locator('section[aria-label="پرونده‌های مجاز"]').isVisible(), 'assembled_member_consultation_dom', 60);
  check(new URL(page.url()).pathname === '/dashboard/consultation' && !blocked && errors.length === 0, 'assembled_member_navigation_observation');
  check(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth), 'assembled_member_mobile_overflow');
  const needles = Object.values(ctx.users).flatMap(u => [u.email, u.password, u.session.token, ...sdkCookies(u.session.cookie).map(x => x.value)]);
  const audit = await storageAudit(page, needles);
  check(audit.hits === 0 && !audit.urlHit, 'assembled_member_private_audit');
  await context.close();
  ctx.pass('assembled-real-member-navigation-and-read-only-dom', { actualAnchorNavigation: true, memberHoldingsMounted: true, consultationMounted: true, viewport: 390, domAutomaticPosts: 0, privateStorageHits: 0, privateUrlHits: 0 });
}
